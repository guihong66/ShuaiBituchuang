<?php
ob_start();
?>

<div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
        <div class="card">
            <div class="card-body p-5">
                <div class="text-center mb-4">
                    <h3 class="fw-bold">用户登录</h3>
                    <p class="text-muted">请输入您的账号和密码</p>
                </div>

                <!-- 公告区域 -->
                <?php if ($loginNotice && $loginNotice['is_active']): ?>
                    <div class="mb-4">
                        <?= $loginNotice['content'] ?>
                    </div>
                <?php endif; ?>

                <form id="loginForm">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">用户名或邮箱</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fas fa-user"></i>
                            </span>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">密码</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fas fa-lock"></i>
                            </span>
                            <input type="password" class="form-control" id="password" name="password" required>
                            <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="remember" name="remember">
                        <label class="form-check-label" for="remember">
                            记住我
                        </label>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary" id="loginBtn">
                            <i class="fas fa-sign-in-alt me-2"></i>
                            登录
                        </button>
                    </div>
                </form>
                
                <div class="text-center mt-4">
                    <p class="text-muted">
                        还没有账号？
                        <a href="/register.php" class="text-decoration-none">立即注册</a>
                    </p>
                    <a href="/index.php" class="text-muted text-decoration-none">
                        <i class="fas fa-arrow-left me-1"></i>返回首页
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$additionalJS = '
<script>
document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.getElementById("loginForm");
    const loginBtn = document.getElementById("loginBtn");
    const togglePassword = document.getElementById("togglePassword");
    const passwordInput = document.getElementById("password");
    
    // 密码显示/隐藏切换
    togglePassword.addEventListener("click", function() {
        const type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
        passwordInput.setAttribute("type", type);
        
        const icon = this.querySelector("i");
        icon.className = type === "password" ? "fas fa-eye" : "fas fa-eye-slash";
    });
    
    // 表单提交
    loginForm.addEventListener("submit", function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const originalText = loginBtn.innerHTML;
        
        // 禁用按钮，显示加载状态
        loginBtn.disabled = true;
        loginBtn.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>登录中...`;
        
        fetch("/login.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showMessage(data.message, "success");
                setTimeout(() => {
                    window.location.href = "/index.php";
                }, 1000);
            } else {
                showMessage(data.message, "danger");
                loginBtn.disabled = false;
                loginBtn.innerHTML = originalText;
            }
        })
        .catch(error => {
            showMessage("网络错误，请稍后再试", "danger");
            loginBtn.disabled = false;
            loginBtn.innerHTML = originalText;
        });
    });
    
    // 回车键快捷登录
    document.addEventListener("keypress", function(e) {
        if (e.key === "Enter" && !loginBtn.disabled) {
            loginForm.dispatchEvent(new Event("submit"));
        }
    });
});
</script>
';

$content = ob_get_clean();
include __DIR__ . '/../layout/base.php';
?> 