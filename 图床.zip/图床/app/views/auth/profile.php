<?php
ob_start();
?>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body text-center">
                <div class="avatar mb-3">
                    <?php if ($user['avatar']): ?>
                        <img src="<?= htmlspecialchars($user['avatar']) ?>" alt="头像" class="rounded-circle" width="100" height="100">
                    <?php else: ?>
                        <div class="bg-primary rounded-circle d-inline-flex align-items-center justify-content-center" style="width: 100px; height: 100px;">
                            <i class="fas fa-user fa-2x text-white"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <h5 class="card-title"><?= htmlspecialchars($user['username']) ?></h5>
                <p class="text-muted"><?= htmlspecialchars($user['email']) ?></p>
                <small class="text-muted">
                    <i class="fas fa-calendar me-1"></i>
                    注册时间：<?= date('Y-m-d', strtotime($user['created_at'])) ?>
                </small>
            </div>
        </div>
        
        <div class="card mt-3">
            <div class="card-body">
                <h6 class="card-title">
                    <i class="fas fa-chart-bar me-2"></i>
                    统计信息
                </h6>
                <div class="row text-center">
                    <div class="col-6">
                        <div class="border-end">
                            <h4 class="text-primary"><?= count($images) ?></h4>
                            <small class="text-muted">图片总数</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <h4 class="text-success"><?= array_sum(array_column($images, 'views')) ?></h4>
                        <small class="text-muted">总浏览量</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-images me-2"></i>
                        我的图片
                    </h5>
                    <div>
                        <button class="btn btn-outline-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editProfileModal">
                            <i class="fas fa-edit me-1"></i>编辑资料
                        </button>
                        <button class="btn btn-outline-secondary btn-sm" data-bs-toggle="modal" data-bs-target="#changePasswordModal">
                            <i class="fas fa-key me-1"></i>修改密码
                        </button>
                    </div>
                </div>
                
                <?php if (empty($images)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-image fa-3x text-muted mb-3"></i>
                        <h6 class="text-muted">还没有上传任何图片</h6>
                        <a href="/index.php" class="btn btn-primary">
                            <i class="fas fa-upload me-2"></i>立即上传
                        </a>
                    </div>
                <?php else: ?>
                    <div class="image-grid">
                        <?php foreach ($images as $image): ?>
                            <div class="image-card">
                                <img src="<?= htmlspecialchars($image['url']) ?>" alt="<?= htmlspecialchars($image['original_name']) ?>">
                                <div class="image-overlay">
                                    <h6 class="mb-1"><?= htmlspecialchars($image['original_name']) ?></h6>
                                    <p class="mb-2 small">
                                        <i class="fas fa-eye me-1"></i><?= $image['views'] ?> 次浏览
                                        <i class="fas fa-clock ms-2 me-1"></i><?= $image['upload_time'] ?>
                                    </p>
                                    <div>
                                        <a href="/index.php?action=view&id=<?= $image['id'] ?>" class="btn btn-sm btn-primary me-1">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <div class="btn-group dropup">
                                            <button class="btn btn-sm btn-success dropdown-toggle" data-bs-toggle="dropdown">
                                                <i class="fas fa-copy"></i>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li><a class="dropdown-item" href="#" onclick="copyToClipboard('<?= htmlspecialchars($image['url']) ?>')">
                                                    <i class="fas fa-link me-2"></i>复制直链
                                                </a></li>
                                                <li><a class="dropdown-item" href="#" onclick="copyToClipboard('<img src=&quot;<?= htmlspecialchars($image['url']) ?>&quot; alt=&quot;<?= htmlspecialchars($image['original_name']) ?>&quot;>')">
                                                    <i class="fas fa-code me-2"></i>复制HTML
                                                </a></li>
                                                <li><a class="dropdown-item" href="#" onclick="copyToClipboard('![<?= htmlspecialchars($image['original_name']) ?>](<?= htmlspecialchars($image['url']) ?>)')">
                                                    <i class="fab fa-markdown me-2"></i>复制Markdown
                                                </a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- 分页 -->
                    <?php if ($pagination['total'] > 1): ?>
                        <nav class="mt-4">
                            <ul class="pagination justify-content-center">
                                <?php if ($pagination['prev']): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?= $pagination['prev'] ?>">上一页</a>
                                    </li>
                                <?php endif; ?>
                                
                                <li class="page-item active">
                                    <span class="page-link"><?= $pagination['current'] ?> / <?= $pagination['total'] ?></span>
                                </li>
                                
                                <?php if ($pagination['next']): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?= $pagination['next'] ?>">下一页</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- 编辑资料模态框 -->
<div class="modal fade" id="editProfileModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">编辑资料</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="editProfileForm">
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                    
                    <div class="mb-3">
                        <label for="edit_username" class="form-label">用户名</label>
                        <input type="text" class="form-control" id="edit_username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_email" class="form-label">邮箱</label>
                        <input type="email" class="form-control" id="edit_email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                    <button type="submit" class="btn btn-primary">保存</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- 修改密码模态框 -->
<div class="modal fade" id="changePasswordModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">修改密码</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="changePasswordForm">
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                    
                    <div class="mb-3">
                        <label for="old_password" class="form-label">当前密码</label>
                        <input type="password" class="form-control" id="old_password" name="old_password" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="new_password" class="form-label">新密码</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" minlength="6" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">确认新密码</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" minlength="6" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                    <button type="submit" class="btn btn-primary">修改密码</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$additionalJS = '
<script>
document.addEventListener("DOMContentLoaded", function() {
    const editProfileForm = document.getElementById("editProfileForm");
    const changePasswordForm = document.getElementById("changePasswordForm");
    
    // 编辑资料表单提交
    editProfileForm.addEventListener("submit", function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        fetch("/profile.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showMessage(data.message, "success");
                setTimeout(() => {
                    location.reload();
                }, 1000);
            } else {
                showMessage(data.message, "danger");
            }
        })
        .catch(error => {
            showMessage("网络错误，请稍后再试", "danger");
        });
    });
    
    // 修改密码表单提交
    changePasswordForm.addEventListener("submit", function(e) {
        e.preventDefault();
        
        const newPassword = document.getElementById("new_password").value;
        const confirmPassword = document.getElementById("confirm_password").value;
        
        if (newPassword !== confirmPassword) {
            showMessage("两次输入的新密码不一致", "danger");
            return;
        }
        
        const formData = new FormData(this);
        
        fetch("/profile.php?action=change_password", {
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showMessage(data.message, "success");
                document.getElementById("changePasswordModal").querySelector(".btn-close").click();
                this.reset();
            } else {
                showMessage(data.message, "danger");
            }
        })
        .catch(error => {
            showMessage("网络错误，请稍后再试", "danger");
        });
    });
});
</script>
';

$content = ob_get_clean();
include __DIR__ . '/../layout/base.php';
?> 