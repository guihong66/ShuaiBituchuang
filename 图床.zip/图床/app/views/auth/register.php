<?php
ob_start();
?>

<div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
        <div class="card">
            <div class="card-body p-5">
                <div class="text-center mb-4">
                    <h3 class="fw-bold">用户注册</h3>
                    <p class="text-muted">创建您的新账号</p>
                </div>

                <!-- 公告区域 -->
                <?php if ($registerNotice && $registerNotice['is_active']): ?>
                    <div class="mb-4">
                        <?= $registerNotice['content'] ?>
                    </div>
                <?php endif; ?>

                <form id="registerForm">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">用户名</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fas fa-user"></i>
                            </span>
                            <input type="text" class="form-control" id="username" name="username" required
                                   pattern="[a-zA-Z0-9_\u4e00-\u9fa5]{2,20}" 
                                   title="用户名长度2-20位，支持中英文、数字和下划线">
                        </div>
                        <div class="form-text">长度2-20位，支持中英文、数字和下划线</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">邮箱地址</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fas fa-envelope"></i>
                            </span>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">密码</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fas fa-lock"></i>
                            </span>
                            <input type="password" class="form-control" id="password" name="password" 
                                   minlength="6" required>
                            <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="form-text">密码长度至少6位</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password_confirm" class="form-label">确认密码</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fas fa-lock"></i>
                            </span>
                            <input type="password" class="form-control" id="password_confirm" name="password_confirm" 
                                   minlength="6" required>
                            <button class="btn btn-outline-secondary" type="button" id="togglePasswordConfirm">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    
                    <!-- 密码强度指示器 -->
                    <div class="mb-3">
                        <div class="password-strength">
                            <div class="progress" style="height: 8px;">
                                <div class="progress-bar" id="strengthBar" role="progressbar" style="width: 0%"></div>
                            </div>
                            <small class="text-muted" id="strengthText">请输入密码</small>
                        </div>
                    </div>
                    
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="agree" required>
                        <label class="form-check-label" for="agree">
                            我已阅读并同意 <a href="#" class="text-decoration-none">服务条款</a> 和 <a href="#" class="text-decoration-none">隐私政策</a>
                        </label>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary" id="registerBtn">
                            <i class="fas fa-user-plus me-2"></i>
                            注册
                        </button>
                    </div>
                </form>
                
                <div class="text-center mt-4">
                    <p class="text-muted">
                        已有账号？
                        <a href="/login.php" class="text-decoration-none">立即登录</a>
                    </p>
                    <a href="/index.php" class="text-muted text-decoration-none">
                        <i class="fas fa-arrow-left me-1"></i>返回首页
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$additionalJS = '
<script>
document.addEventListener("DOMContentLoaded", function() {
    const registerForm = document.getElementById("registerForm");
    const registerBtn = document.getElementById("registerBtn");
    const togglePassword = document.getElementById("togglePassword");
    const togglePasswordConfirm = document.getElementById("togglePasswordConfirm");
    const passwordInput = document.getElementById("password");
    const passwordConfirmInput = document.getElementById("password_confirm");
    const strengthBar = document.getElementById("strengthBar");
    const strengthText = document.getElementById("strengthText");
    
    // 密码显示/隐藏切换
    function setupPasswordToggle(button, input) {
        button.addEventListener("click", function() {
            const type = input.getAttribute("type") === "password" ? "text" : "password";
            input.setAttribute("type", type);
            
            const icon = this.querySelector("i");
            icon.className = type === "password" ? "fas fa-eye" : "fas fa-eye-slash";
        });
    }
    
    setupPasswordToggle(togglePassword, passwordInput);
    setupPasswordToggle(togglePasswordConfirm, passwordConfirmInput);
    
    // 密码强度检测
    passwordInput.addEventListener("input", function() {
        const password = this.value;
        const strength = calculatePasswordStrength(password);
        
        strengthBar.style.width = strength.percent + "%";
        strengthBar.className = "progress-bar " + strength.class;
        strengthText.textContent = strength.text;
    });
    
    // 密码确认验证
    passwordConfirmInput.addEventListener("input", function() {
        if (this.value && this.value !== passwordInput.value) {
            this.setCustomValidity("密码不一致");
            this.classList.add("is-invalid");
        } else {
            this.setCustomValidity("");
            this.classList.remove("is-invalid");
        }
    });
    
    // 表单提交
    registerForm.addEventListener("submit", function(e) {
        e.preventDefault();
        
        // 验证密码一致性
        if (passwordInput.value !== passwordConfirmInput.value) {
            showMessage("两次输入的密码不一致", "danger");
            return;
        }
        
        const formData = new FormData(this);
        const originalText = registerBtn.innerHTML;
        
        // 禁用按钮，显示加载状态
        registerBtn.disabled = true;
        registerBtn.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>注册中...`;
        
        fetch("/register.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showMessage(data.message, "success");
                setTimeout(() => {
                    window.location.href = "/index.php";
                }, 1000);
            } else {
                showMessage(data.message, "danger");
                registerBtn.disabled = false;
                registerBtn.innerHTML = originalText;
            }
        })
        .catch(error => {
            showMessage("网络错误，请稍后再试", "danger");
            registerBtn.disabled = false;
            registerBtn.innerHTML = originalText;
        });
    });
    
    // 密码强度计算
    function calculatePasswordStrength(password) {
        let score = 0;
        let feedback = [];
        
        if (password.length >= 6) score += 20;
        if (password.length >= 8) score += 10;
        if (/[a-z]/.test(password)) score += 10;
        if (/[A-Z]/.test(password)) score += 15;
        if (/[0-9]/.test(password)) score += 15;
        if (/[^a-zA-Z0-9]/.test(password)) score += 20;
        if (password.length >= 12) score += 10;
        
        let result = {
            percent: Math.min(score, 100),
            class: "",
            text: ""
        };
        
        if (score < 30) {
            result.class = "bg-danger";
            result.text = "密码强度：弱";
        } else if (score < 60) {
            result.class = "bg-warning";
            result.text = "密码强度：中等";
        } else if (score < 80) {
            result.class = "bg-info";
            result.text = "密码强度：良好";
        } else {
            result.class = "bg-success";
            result.text = "密码强度：强";
        }
        
        return result;
    }
});
</script>
';

$content = ob_get_clean();
include __DIR__ . '/../layout/base.php';
?> 