<?php
ob_start();
?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-cog me-2"></i>
                    系统设置
                </h6>
            </div>
            <div class="card-body">
                <form id="settingsForm">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                    
                    <!-- 基本设置 -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-info-circle me-2"></i>
                                基本设置
                            </h6>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="site_name" class="form-label">网站名称</label>
                                <input type="text" class="form-control" id="site_name" name="site_name" 
                                       value="<?= htmlspecialchars($configs['site_name'] ?? '我的图床') ?>" required>
                                <div class="form-text">显示在网站标题和导航栏</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title_suffix" class="form-label">标题后缀</label>
                                <input type="text" class="form-control" id="title_suffix" name="title_suffix" 
                                       value="<?= htmlspecialchars($configs['title_suffix'] ?? ' - 免费图片存储') ?>">
                                <div class="form-text">显示在浏览器标题栏</div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="mb-3">
                                <label for="description" class="form-label">网站描述</label>
                                <textarea class="form-control" id="description" name="description" rows="3"><?= htmlspecialchars($configs['description'] ?? '简单、快速、稳定的图片存储服务') ?></textarea>
                                <div class="form-text">显示在首页打字机效果中</div>
                            </div>
                        </div>
                    </div>

                    <!-- 上传设置 -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-upload me-2"></i>
                                上传设置
                            </h6>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="max_file_size" class="form-label">最大文件大小 (字节)</label>
                                <input type="number" class="form-control" id="max_file_size" name="max_file_size" 
                                       value="<?= htmlspecialchars($configs['max_file_size'] ?? '5242880') ?>" min="1048576" max="104857600">
                                <div class="form-text">
                                    当前设置: <?= round(($configs['max_file_size'] ?? 5242880) / 1024 / 1024, 2) ?> MB
                                    (建议: 1-100 MB)
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="allowed_extensions" class="form-label">允许的文件扩展名</label>
                                <input type="text" class="form-control" id="allowed_extensions" name="allowed_extensions" 
                                       value="<?= htmlspecialchars($configs['allowed_extensions'] ?? 'jpg,jpeg,png,gif,bmp,webp') ?>">
                                <div class="form-text">用英文逗号分隔，如: jpg,png,gif</div>
                            </div>
                        </div>
                    </div>

                    <!-- 权限设置 -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-shield-alt me-2"></i>
                                权限设置
                            </h6>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="allow_guest_upload" 
                                           name="allow_guest_upload" <?= ($configs['allow_guest_upload'] ?? '1') == '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="allow_guest_upload">
                                        允许游客上传
                                    </label>
                                </div>
                                <div class="form-text">是否允许未登录用户上传图片</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="allow_registration" 
                                           name="allow_registration" <?= ($configs['allow_registration'] ?? '1') == '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="allow_registration">
                                        允许用户注册
                                    </label>
                                </div>
                                <div class="form-text">是否开放用户注册功能</div>
                            </div>
                        </div>
                    </div>

                    <!-- 画廊设置 -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-images me-2"></i>
                                画廊设置
                            </h6>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="gallery_enabled" 
                                           name="gallery_enabled" <?= ($configs['gallery_enabled'] ?? '1') == '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="gallery_enabled">
                                        启用画廊功能
                                    </label>
                                </div>
                                <div class="form-text">是否允许用户访问图片画廊</div>
                            </div>
                        </div>
                    </div>

                    <!-- 界面设置 -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-palette me-2"></i>
                                界面设置
                            </h6>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="typewriter_enabled" 
                                           name="typewriter_enabled" <?= ($configs['typewriter_enabled'] ?? '1') == '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="typewriter_enabled">
                                        启用打字机效果
                                    </label>
                                </div>
                                <div class="form-text">是否在首页显示打字机动画效果</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="typewriter_speed" class="form-label">打字机速度 (毫秒)</label>
                                <input type="number" class="form-control" id="typewriter_speed" name="typewriter_speed" 
                                       value="<?= htmlspecialchars($configs['typewriter_speed'] ?? '100') ?>" min="50" max="500">
                                <div class="form-text">数字越小打字越快 (建议: 50-200)</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="sakura_enabled" 
                                           name="sakura_enabled" <?= ($configs['sakura_enabled'] ?? '0') == '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="sakura_enabled">
                                        启用樱花飘落效果
                                    </label>
                                </div>
                                <div class="form-text">在首页显示樱花飘落动画</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="background_image" class="form-label">背景图片地址</label>
                                <input type="url" class="form-control" id="background_image" name="background_image" 
                                       value="<?= htmlspecialchars($configs['background_image'] ?? '') ?>" placeholder="https://example.com/background.jpg">
                                <div class="form-text">留空使用默认背景</div>
                            </div>
                        </div>
                    </div>

                    <!-- 保存按钮 -->
                    <div class="row">
                        <div class="col-12">
                            <hr>
                            <div class="d-flex justify-content-between">
                                <div>
                                    <small class="text-muted">
                                        <i class="fas fa-info-circle me-1"></i>
                                        修改设置后会立即生效，请谨慎操作
                                    </small>
                                </div>
                                <div>
                                    <button type="button" class="btn btn-secondary me-2" onclick="location.reload()">
                                        <i class="fas fa-undo me-2"></i>
                                        重置
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>
                                        保存设置
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- 设置预览 -->
<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-eye me-2"></i>
                    当前配置预览
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <h6>基本信息</h6>
                        <ul class="list-unstyled">
                            <li><strong>网站名称:</strong> <?= htmlspecialchars($configs['site_name'] ?? '我的图床') ?></li>
                            <li><strong>标题后缀:</strong> <?= htmlspecialchars($configs['title_suffix'] ?? ' - 免费图片存储') ?></li>
                            <li><strong>网站描述:</strong> <?= htmlspecialchars($configs['description'] ?? '简单、快速、稳定的图片存储服务') ?></li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <h6>上传配置</h6>
                        <ul class="list-unstyled">
                            <li><strong>最大文件大小:</strong> <?= round(($configs['max_file_size'] ?? 5242880) / 1024 / 1024, 2) ?> MB</li>
                            <li><strong>允许的格式:</strong> <?= htmlspecialchars($configs['allowed_extensions'] ?? 'jpg,jpeg,png,gif,bmp,webp') ?></li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <h6>权限设置</h6>
                        <ul class="list-unstyled">
                            <li><strong>游客上传:</strong> 
                                <?= ($configs['allow_guest_upload'] ?? '1') == '1' ? '<span class="text-success">允许</span>' : '<span class="text-danger">禁止</span>' ?>
                            </li>
                            <li><strong>用户注册:</strong> 
                                <?= ($configs['allow_registration'] ?? '1') == '1' ? '<span class="text-success">开放</span>' : '<span class="text-danger">关闭</span>' ?>
                            </li>
                            <li><strong>画廊功能:</strong> 
                                <?= ($configs['gallery_enabled'] ?? '1') == '1' ? '<span class="text-success">启用</span>' : '<span class="text-danger">禁用</span>' ?>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-6">
                        <h6>界面设置</h6>
                        <ul class="list-unstyled">
                            <li><strong>打字机效果:</strong> 
                                <?= ($configs['typewriter_enabled'] ?? '1') == '1' ? '<span class="text-success">启用</span>' : '<span class="text-danger">禁用</span>' ?>
                            </li>
                            <li><strong>打字机速度:</strong> <?= htmlspecialchars($configs['typewriter_speed'] ?? '100') ?> 毫秒</li>
                            <li><strong>樱花飘落:</strong> 
                                <?= ($configs['sakura_enabled'] ?? '0') == '1' ? '<span class="text-success">启用</span>' : '<span class="text-danger">禁用</span>' ?>
                            </li>
                            <li><strong>背景图片:</strong> 
                                <?php if (!empty($configs['background_image'])): ?>
                                    <span class="text-info">已设置</span>
                                <?php else: ?>
                                    <span class="text-muted">默认樱花粉</span>
                                <?php endif; ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$additionalJS = '
<script>
document.addEventListener("DOMContentLoaded", function() {
    const settingsForm = document.getElementById("settingsForm");
    
    // 文件大小实时计算
    const fileSizeInput = document.getElementById("max_file_size");
    const fileSizeHelp = fileSizeInput.nextElementSibling;
    
    fileSizeInput.addEventListener("input", function() {
        const sizeInMB = (this.value / 1024 / 1024).toFixed(2);
        fileSizeHelp.innerHTML = `当前设置: ${sizeInMB} MB (建议: 1-100 MB)`;
    });
    
    // 表单提交
    settingsForm.addEventListener("submit", function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const submitBtn = this.querySelector("button[type=submit]");
        const originalText = submitBtn.innerHTML;
        
        // 禁用按钮，显示加载状态
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>保存中...`;
        
        adminRequest("/admin/?action=settings", {
            csrf_token: formData.get("csrf_token"),
            site_name: formData.get("site_name"),
            title_suffix: formData.get("title_suffix"),
            description: formData.get("description"),
            max_file_size: formData.get("max_file_size"),
            allowed_extensions: formData.get("allowed_extensions"),
            allow_guest_upload: formData.get("allow_guest_upload") === "on" ? "1" : "0",
            allow_registration: formData.get("allow_registration") === "on" ? "1" : "0",
            gallery_enabled: formData.get("gallery_enabled") === "on" ? "1" : "0",
            typewriter_enabled: formData.get("typewriter_enabled") === "on" ? "1" : "0",
            typewriter_speed: formData.get("typewriter_speed"),
            sakura_enabled: formData.get("sakura_enabled") === "on" ? "1" : "0",
            background_image: formData.get("background_image")
        }, function(response) {
            showAdminMessage(response.message, "success");
            setTimeout(() => {
                location.reload();
            }, 1500);
        }, function(error) {
            showAdminMessage(error, "danger");
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        });
    });
});
</script>
';

$content = ob_get_clean();
include __DIR__ . '/../layout/admin.php';
?> 