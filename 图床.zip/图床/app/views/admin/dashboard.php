<?php
ob_start();
?>

<!-- 统计卡片 -->
<div class="row mb-4">
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stat-card">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div class="stat-number"><?= number_format($stats['total_users']) ?></div>
                    <div>总用户数</div>
                    <small>今日新增: <?= $stats['today_users'] ?></small>
                </div>
                <div>
                    <i class="fas fa-users fa-2x opacity-75"></i>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stat-card success">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div class="stat-number"><?= number_format($stats['total_images']) ?></div>
                    <div>总图片数</div>
                    <small>今日新增: <?= $stats['today_images'] ?></small>
                </div>
                <div>
                    <i class="fas fa-images fa-2x opacity-75"></i>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stat-card warning">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div class="stat-number"><?= number_format($stats['total_views']) ?></div>
                    <div>总浏览量</div>
                    <small>图片点击次数</small>
                </div>
                <div>
                    <i class="fas fa-eye fa-2x opacity-75"></i>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-3 col-md-6 mb-3">
        <div class="stat-card danger">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div class="stat-number"><?= $stats['storage_used'] ?></div>
                    <div>存储使用</div>
                    <small>图片总大小</small>
                </div>
                <div>
                    <i class="fas fa-hdd fa-2x opacity-75"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 快速操作 -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-bolt me-2"></i>
                    快速操作
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-2">
                        <a href="/admin/?action=users" class="btn btn-outline-primary btn-admin w-100">
                            <i class="fas fa-users me-2"></i>
                            用户管理
                        </a>
                    </div>
                    <div class="col-md-3 mb-2">
                        <a href="/admin/?action=images" class="btn btn-outline-success btn-admin w-100">
                            <i class="fas fa-images me-2"></i>
                            图片管理
                        </a>
                    </div>
                    <div class="col-md-3 mb-2">
                        <a href="/admin/?action=settings" class="btn btn-outline-warning btn-admin w-100">
                            <i class="fas fa-cog me-2"></i>
                            系统设置
                        </a>
                    </div>
                    <div class="col-md-3 mb-2">
                        <a href="/admin/?action=notices" class="btn btn-outline-info btn-admin w-100">
                            <i class="fas fa-bullhorn me-2"></i>
                            公告管理
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 最近活动 -->
<div class="row">
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-clock me-2"></i>
                    最近上传的图片
                </h6>
            </div>
            <div class="card-body">
                <?php if (empty($recentImages)): ?>
                    <p class="text-muted text-center mb-0">暂无图片</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>图片</th>
                                    <th>文件名</th>
                                    <th>上传者</th>
                                    <th>时间</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentImages as $image): ?>
                                    <tr>
                                        <td>
                                            <img src="<?= htmlspecialchars($image['url']) ?>" 
                                                 alt="<?= htmlspecialchars($image['original_name']) ?>" 
                                                 class="image-thumb">
                                        </td>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars($image['original_name']) ?></div>
                                            <small class="text-muted">
                                                <?= htmlspecialchars($image['mime_type']) ?> • 
                                                <?= $image['views'] ?> 次浏览
                                            </small>
                                        </td>
                                        <td>
                                            <?php if ($image['username']): ?>
                                                <div class="user-avatar">
                                                    <?= strtoupper(substr($image['username'], 0, 1)) ?>
                                                </div>
                                                <span class="ms-2"><?= htmlspecialchars($image['username']) ?></span>
                                            <?php else: ?>
                                                <span class="text-muted">游客</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?= date('m-d H:i', strtotime($image['created_at'])) ?>
                                            </small>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-user-plus me-2"></i>
                    最近注册的用户
                </h6>
            </div>
            <div class="card-body">
                <?php if (empty($recentUsers)): ?>
                    <p class="text-muted text-center mb-0">暂无用户</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>用户</th>
                                    <th>邮箱</th>
                                    <th>注册时间</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentUsers as $user): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="user-avatar me-2">
                                                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                                                </div>
                                                <div>
                                                    <div class="fw-bold"><?= htmlspecialchars($user['username']) ?></div>
                                                    <small class="text-muted">ID: <?= $user['id'] ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <small><?= htmlspecialchars($user['email']) ?></small>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?= date('m-d H:i', strtotime($user['created_at'])) ?>
                                            </small>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- 系统信息 -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-info-circle me-2"></i>
                    系统信息
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <strong>PHP版本</strong><br>
                        <span class="text-muted"><?= PHP_VERSION ?></span>
                    </div>
                    <div class="col-md-3">
                        <strong>服务器软件</strong><br>
                        <span class="text-muted"><?= $_SERVER['SERVER_SOFTWARE'] ?? '未知' ?></span>
                    </div>
                    <div class="col-md-3">
                        <strong>运行时间</strong><br>
                        <span class="text-muted"><?= date('Y-m-d H:i:s') ?></span>
                    </div>
                    <div class="col-md-3">
                        <strong>内存使用</strong><br>
                        <span class="text-muted"><?= round(memory_get_usage(true) / 1024 / 1024, 2) ?> MB</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/admin.php';
?> 