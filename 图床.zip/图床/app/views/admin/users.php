<?php
ob_start();
?>

<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">
                        <i class="fas fa-users me-2"></i>
                        用户管理
                    </h6>
                    <div>
                        <span class="badge bg-primary"><?= count($users) ?> 个用户</span>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if (empty($users)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-users fa-3x text-muted mb-3"></i>
                        <h6 class="text-muted">暂无用户</h6>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>用户</th>
                                    <th>邮箱</th>
                                    <th>角色</th>
                                    <th>状态</th>
                                    <th>注册时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): ?>
                                    <tr id="user-<?= $user['id'] ?>">
                                        <td><?= $user['id'] ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="user-avatar me-3">
                                                    <?= strtoupper(substr($user['username'], 0, 1)) ?>
                                                </div>
                                                <div>
                                                    <div class="fw-bold"><?= htmlspecialchars($user['username']) ?></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?= htmlspecialchars($user['email']) ?></td>
                                        <td>
                                            <?php if ($user['role'] === 'admin'): ?>
                                                <span class="badge bg-danger">管理员</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">普通用户</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($user['status'] == 1): ?>
                                                <span class="badge bg-success badge-status">正常</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger badge-status">已禁用</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?= date('Y-m-d H:i', strtotime($user['created_at'])) ?>
                                            </small>
                                        </td>
                                        <td>
                                            <?php if ($user['role'] !== 'admin'): ?>
                                                <div class="btn-group btn-group-sm">
                                                    <button class="btn btn-outline-primary btn-sm" 
                                                            onclick="editUser(<?= $user['id'] ?>, '<?= htmlspecialchars($user['username']) ?>', '<?= htmlspecialchars($user['email']) ?>')">
                                                        <i class="fas fa-edit"></i>
                                                        编辑
                                                    </button>
                                                    <button class="btn btn-outline-warning btn-sm" 
                                                            onclick="toggleUserStatus(<?= $user['id'] ?>, '<?= $user['status'] == 1 ? '禁用' : '启用' ?>')">
                                                        <i class="fas fa-<?= $user['status'] == 1 ? 'ban' : 'check' ?>"></i>
                                                        <?= $user['status'] == 1 ? '禁用' : '启用' ?>
                                                    </button>
                                                    <button class="btn btn-outline-danger btn-sm" 
                                                            onclick="deleteUser(<?= $user['id'] ?>, '<?= htmlspecialchars($user['username']) ?>')">
                                                        <i class="fas fa-trash"></i>
                                                        删除
                                                    </button>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted">管理员</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- 分页 -->
                    <?php if ($pagination['total'] > 1): ?>
                        <nav class="mt-4">
                            <ul class="pagination justify-content-center">
                                <?php if ($pagination['prev']): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?action=users&page=<?= $pagination['prev'] ?>">上一页</a>
                                    </li>
                                <?php endif; ?>
                                
                                <li class="page-item active">
                                    <span class="page-link"><?= $pagination['current'] ?> / <?= $pagination['total'] ?></span>
                                </li>
                                
                                <?php if ($pagination['next']): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?action=users&page=<?= $pagination['next'] ?>">下一页</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- 编辑用户模态框 -->
<div class="modal fade" id="editUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">编辑用户</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="editUserForm">
                    <input type="hidden" id="editUserId" name="user_id">
                    <div class="mb-3">
                        <label for="editUsername" class="form-label">用户名</label>
                        <input type="text" class="form-control" id="editUsername" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="editEmail" class="form-label">邮箱</label>
                        <input type="email" class="form-control" id="editEmail" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="editPassword" class="form-label">新密码（留空表示不修改）</label>
                        <input type="password" class="form-control" id="editPassword" name="password" minlength="6">
                        <div class="form-text">密码长度至少6位</div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                <button type="button" class="btn btn-primary" onclick="confirmEditUser()">保存修改</button>
            </div>
        </div>
    </div>
</div>

<!-- 删除用户模态框 -->
<div class="modal fade" id="deleteUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">删除用户</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>确定要删除用户 <strong id="deleteUserName"></strong> 吗？</p>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="keepImages" checked>
                    <label class="form-check-label" for="keepImages">
                        保留该用户上传的图片（推荐）
                    </label>
                </div>
                <div class="alert alert-warning mt-3">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    此操作不可恢复，请谨慎操作！
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                <button type="button" class="btn btn-danger" onclick="confirmDeleteUser()">确认删除</button>
            </div>
        </div>
    </div>
</div>

<?php
$additionalJS = '
<script>
let currentUserId = null;

// 编辑用户
function editUser(userId, username, email) {
    document.getElementById("editUserId").value = userId;
    document.getElementById("editUsername").value = username;
    document.getElementById("editEmail").value = email;
    document.getElementById("editPassword").value = "";
    
    const modal = new bootstrap.Modal(document.getElementById("editUserModal"));
    modal.show();
}

// 确认编辑用户
function confirmEditUser() {
    const form = document.getElementById("editUserForm");
    const formData = new FormData(form);
    
    const data = {
        csrf_token: window.csrfToken,
        action: "edit",
        user_id: formData.get("user_id"),
        username: formData.get("username"),
        email: formData.get("email")
    };
    
    // 只在填写了密码时才包含密码
    if (formData.get("password")) {
        data.password = formData.get("password");
    }
    
    adminRequest("/admin/?action=users", data, function(response) {
        showAdminMessage(response.message, "success");
        setTimeout(() => {
            location.reload();
        }, 1000);
        
        // 关闭模态框
        const modal = bootstrap.Modal.getInstance(document.getElementById("editUserModal"));
        modal.hide();
    }, function(error) {
        showAdminMessage(error, "danger");
    });
}

// 切换用户状态
function toggleUserStatus(userId, action) {
    if (!confirm(`确定要${action}此用户吗？`)) {
        return;
    }
    
    adminRequest("/admin/?action=users", {
        csrf_token: window.csrfToken,
        action: "toggle_status",
        user_id: userId
    }, function(response) {
        showAdminMessage(response.message, "success");
        setTimeout(() => {
            location.reload();
        }, 1000);
    }, function(error) {
        showAdminMessage(error, "danger");
    });
}

// 删除用户
function deleteUser(userId, username) {
    currentUserId = userId;
    document.getElementById("deleteUserName").textContent = username;
    
    const modal = new bootstrap.Modal(document.getElementById("deleteUserModal"));
    modal.show();
}

// 确认删除用户
function confirmDeleteUser() {
    const keepImages = document.getElementById("keepImages").checked;
    
    adminRequest("/admin/?action=users", {
        csrf_token: window.csrfToken,
        action: "delete",
        user_id: currentUserId,
        keep_images: keepImages ? "1" : ""
    }, function(response) {
        showAdminMessage(response.message, "success");
        setTimeout(() => {
            location.reload();
        }, 1000);
    }, function(error) {
        showAdminMessage(error, "danger");
    });
    
    // 关闭模态框
    const modal = bootstrap.Modal.getInstance(document.getElementById("deleteUserModal"));
    modal.hide();
}
</script>
';

$content = ob_get_clean();
include __DIR__ . '/../layout/admin.php';
?> 