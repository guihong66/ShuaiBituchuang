<?php
ob_start();

// 辅助函数：获取公告内容
function getNoticeContent($notices, $position) {
    foreach ($notices as $notice) {
        if ($notice['position'] === $position) {
            return $notice['content'];
        }
    }
    return '';
}

// 辅助函数：获取公告状态
function getNoticeStatus($notices, $position) {
    foreach ($notices as $notice) {
        if ($notice['position'] === $position) {
            return $notice['is_active'] == 1;
        }
    }
    return false;
}
?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-bullhorn me-2"></i>
                    公告管理
                </h6>
            </div>
            <div class="card-body">
                <form id="noticesForm">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                    
                    <!-- 首页公告 -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-home me-2"></i>
                                首页公告
                            </h6>
                        </div>
                        <div class="col-12">
                            <div class="mb-3">
                                <div class="form-check form-switch mb-2">
                                    <input class="form-check-input" type="checkbox" id="home_notice_active" 
                                           name="home_notice_active" <?= getNoticeStatus($notices, 'home') ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="home_notice_active">
                                        启用首页公告
                                    </label>
                                </div>
                                <textarea class="form-control" id="home_notice" name="home_notice" rows="4" 
                                          placeholder="请输入首页公告内容，支持HTML标签"><?= htmlspecialchars(getNoticeContent($notices, 'home')) ?></textarea>
                                <div class="form-text">显示在首页上传区域上方，支持HTML格式</div>
                            </div>
                        </div>
                    </div>

                    <!-- 登录页公告 -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-sign-in-alt me-2"></i>
                                登录页公告
                            </h6>
                        </div>
                        <div class="col-12">
                            <div class="mb-3">
                                <div class="form-check form-switch mb-2">
                                    <input class="form-check-input" type="checkbox" id="login_notice_active" 
                                           name="login_notice_active" <?= getNoticeStatus($notices, 'login') ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="login_notice_active">
                                        启用登录页公告
                                    </label>
                                </div>
                                <textarea class="form-control" id="login_notice" name="login_notice" rows="4" 
                                          placeholder="请输入登录页公告内容，支持HTML标签"><?= htmlspecialchars(getNoticeContent($notices, 'login')) ?></textarea>
                                <div class="form-text">显示在登录表单上方，支持HTML格式</div>
                            </div>
                        </div>
                    </div>

                    <!-- 注册页公告 -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6 class="border-bottom pb-2 mb-3">
                                <i class="fas fa-user-plus me-2"></i>
                                注册页公告
                            </h6>
                        </div>
                        <div class="col-12">
                            <div class="mb-3">
                                <div class="form-check form-switch mb-2">
                                    <input class="form-check-input" type="checkbox" id="register_notice_active" 
                                           name="register_notice_active" <?= getNoticeStatus($notices, 'register') ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="register_notice_active">
                                        启用注册页公告
                                    </label>
                                </div>
                                <textarea class="form-control" id="register_notice" name="register_notice" rows="4" 
                                          placeholder="请输入注册页公告内容，支持HTML标签"><?= htmlspecialchars(getNoticeContent($notices, 'register')) ?></textarea>
                                <div class="form-text">显示在注册表单上方，支持HTML格式</div>
                            </div>
                        </div>
                    </div>

                    <!-- 保存按钮 -->
                    <div class="row">
                        <div class="col-12">
                            <hr>
                            <div class="d-flex justify-content-between">
                                <div>
                                    <small class="text-muted">
                                        <i class="fas fa-info-circle me-1"></i>
                                        公告支持HTML标签，可以设置样式和链接
                                    </small>
                                </div>
                                <div>
                                    <button type="button" class="btn btn-secondary me-2" onclick="location.reload()">
                                        <i class="fas fa-undo me-2"></i>
                                        重置
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>
                                        保存公告
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- 公告预览 -->
<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-eye me-2"></i>
                    公告预览
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <h6>首页公告</h6>
                        <div class="border rounded p-3 bg-light">
                            <?php if (getNoticeStatus($notices, 'home')): ?>
                                <?= getNoticeContent($notices, 'home') ?>
                            <?php else: ?>
                                <span class="text-muted">公告已禁用</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <h6>登录页公告</h6>
                        <div class="border rounded p-3 bg-light">
                            <?php if (getNoticeStatus($notices, 'login')): ?>
                                <?= getNoticeContent($notices, 'login') ?>
                            <?php else: ?>
                                <span class="text-muted">公告已禁用</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <h6>注册页公告</h6>
                        <div class="border rounded p-3 bg-light">
                            <?php if (getNoticeStatus($notices, 'register')): ?>
                                <?= getNoticeContent($notices, 'register') ?>
                            <?php else: ?>
                                <span class="text-muted">公告已禁用</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- HTML标签帮助 -->
<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-question-circle me-2"></i>
                    常用HTML标签
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>基本标签</h6>
                        <ul class="list-unstyled">
                            <li><code>&lt;strong&gt;粗体文字&lt;/strong&gt;</code></li>
                            <li><code>&lt;em&gt;斜体文字&lt;/em&gt;</code></li>
                            <li><code>&lt;br&gt;</code> - 换行</li>
                            <li><code>&lt;a href="链接"&gt;链接文字&lt;/a&gt;</code></li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <h6>Bootstrap样式</h6>
                        <ul class="list-unstyled">
                            <li><code>&lt;div class="alert alert-info"&gt;信息提示&lt;/div&gt;</code></li>
                            <li><code>&lt;div class="alert alert-warning"&gt;警告提示&lt;/div&gt;</code></li>
                            <li><code>&lt;div class="alert alert-success"&gt;成功提示&lt;/div&gt;</code></li>
                            <li><code>&lt;div class="alert alert-danger"&gt;错误提示&lt;/div&gt;</code></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$additionalJS = '
<script>
document.addEventListener("DOMContentLoaded", function() {
    const noticesForm = document.getElementById("noticesForm");
    
    // 表单提交
    noticesForm.addEventListener("submit", function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const submitBtn = this.querySelector("button[type=submit]");
        const originalText = submitBtn.innerHTML;
        
        // 禁用按钮，显示加载状态
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>保存中...`;
        
        adminRequest("/admin/?action=notices", {
            home_notice: formData.get("home_notice"),
            home_notice_active: formData.get("home_notice_active") ? "1" : "",
            login_notice: formData.get("login_notice"),
            login_notice_active: formData.get("login_notice_active") ? "1" : "",
            register_notice: formData.get("register_notice"),
            register_notice_active: formData.get("register_notice_active") ? "1" : ""
        }, function(response) {
            showAdminMessage(response.message, "success");
            setTimeout(() => {
                location.reload();
            }, 1500);
        }, function(error) {
            showAdminMessage(error, "danger");
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        });
    });
});
</script>
';

$content = ob_get_clean();
include __DIR__ . '/../layout/admin.php';
?> 