<?php
ob_start();
?>

<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">
                        <i class="fas fa-images me-2"></i>
                        图片管理
                    </h6>
                    <div>
                        <span class="badge bg-primary"><?= count($images) ?> 张图片</span>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if (empty($images)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-images fa-3x text-muted mb-3"></i>
                        <h6 class="text-muted">暂无图片</h6>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>图片</th>
                                    <th>文件信息</th>
                                    <th>上传者</th>
                                    <th>尺寸</th>
                                    <th>浏览</th>
                                    <th>上传时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($images as $image): ?>
                                    <tr id="image-<?= $image['id'] ?>">
                                        <td>
                                            <img src="<?= htmlspecialchars($image['url']) ?>" 
                                                 alt="<?= htmlspecialchars($image['original_name']) ?>" 
                                                 class="image-thumb"
                                                 onclick="viewImage('<?= htmlspecialchars($image['url']) ?>', '<?= htmlspecialchars($image['original_name']) ?>')">
                                        </td>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars($image['original_name']) ?></div>
                                            <small class="text-muted">
                                                <?= htmlspecialchars($image['mime_type']) ?><br>
                                                <?= $image['formatted_size'] ?> • ID: <?= $image['id'] ?>
                                            </small>
                                        </td>
                                        <td>
                                            <?php if ($image['username']): ?>
                                                <div class="d-flex align-items-center">
                                                    <div class="user-avatar me-2">
                                                        <?= strtoupper(substr($image['username'], 0, 1)) ?>
                                                    </div>
                                                    <div>
                                                        <div class="fw-bold"><?= htmlspecialchars($image['username']) ?></div>
                                                        <small class="text-muted">注册用户</small>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted">
                                                    <i class="fas fa-user-secret me-1"></i>
                                                    游客上传
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($image['width'] && $image['height']): ?>
                                                <small class="text-muted">
                                                    <?= $image['width'] ?> × <?= $image['height'] ?>
                                                </small>
                                            <?php else: ?>
                                                <small class="text-muted">-</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-info"><?= number_format($image['views']) ?></span>
                                        </td>
                                        <td>
                                            <small class="text-muted">
                                                <?= $image['upload_time'] ?><br>
                                                <?= date('Y-m-d H:i', strtotime($image['created_at'])) ?>
                                            </small>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <button class="btn btn-outline-primary btn-sm" 
                                                        onclick="copyImageUrl('<?= htmlspecialchars($image['url']) ?>')">
                                                    <i class="fas fa-copy"></i>
                                                    复制
                                                </button>
                                                <a href="<?= htmlspecialchars($image['url']) ?>" 
                                                   target="_blank" class="btn btn-outline-info btn-sm">
                                                    <i class="fas fa-external-link-alt"></i>
                                                    查看
                                                </a>
                                                <button class="btn btn-outline-danger btn-sm" 
                                                        onclick="deleteImage(<?= $image['id'] ?>, '<?= htmlspecialchars($image['original_name']) ?>')">
                                                    <i class="fas fa-trash"></i>
                                                    删除
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- 分页 -->
                    <?php if ($pagination['total'] > 1): ?>
                        <nav class="mt-4">
                            <ul class="pagination justify-content-center">
                                <?php if ($pagination['prev']): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?action=images&page=<?= $pagination['prev'] ?>">上一页</a>
                                    </li>
                                <?php endif; ?>
                                
                                <li class="page-item active">
                                    <span class="page-link"><?= $pagination['current'] ?> / <?= $pagination['total'] ?></span>
                                </li>
                                
                                <?php if ($pagination['next']): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?action=images&page=<?= $pagination['next'] ?>">下一页</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- 图片查看模态框 -->
<div class="modal fade" id="imageViewModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="imageViewTitle">查看图片</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <img id="imageViewImg" src="" alt="" class="img-fluid" style="max-height: 500px;">
            </div>
        </div>
    </div>
</div>

<!-- 删除图片模态框 -->
<div class="modal fade" id="deleteImageModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">删除图片</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>确定要删除图片 <strong id="deleteImageName"></strong> 吗？</p>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    此操作不可恢复，图片文件将被永久删除！
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                <button type="button" class="btn btn-danger" onclick="confirmDeleteImage()">确认删除</button>
            </div>
        </div>
    </div>
</div>

<?php
$additionalJS = '
<script>
let currentImageId = null;

// 查看图片
function viewImage(url, name) {
    document.getElementById("imageViewTitle").textContent = name;
    document.getElementById("imageViewImg").src = url;
    document.getElementById("imageViewImg").alt = name;
    
    const modal = new bootstrap.Modal(document.getElementById("imageViewModal"));
    modal.show();
}

// 复制图片链接
function copyImageUrl(url) {
    navigator.clipboard.writeText(url).then(() => {
        showAdminMessage("图片链接已复制到剪贴板", "success");
    }).catch(() => {
        // 备用方案
        const textArea = document.createElement("textarea");
        textArea.value = url;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand("copy");
        document.body.removeChild(textArea);
        showAdminMessage("图片链接已复制到剪贴板", "success");
    });
}

// 删除图片
function deleteImage(imageId, imageName) {
    currentImageId = imageId;
    document.getElementById("deleteImageName").textContent = imageName;
    
    const modal = new bootstrap.Modal(document.getElementById("deleteImageModal"));
    modal.show();
}

// 确认删除图片
function confirmDeleteImage() {
    adminRequest("/admin/?action=images", {
        action: "delete",
        image_id: currentImageId
    }, function(response) {
        showAdminMessage(response.message, "success");
        
        // 移除表格行
        const row = document.getElementById("image-" + currentImageId);
        if (row) {
            row.remove();
        }
        
        // 关闭模态框
        const modal = bootstrap.Modal.getInstance(document.getElementById("deleteImageModal"));
        modal.hide();
    }, function(error) {
        showAdminMessage(error, "danger");
    });
}
</script>
';

$content = ob_get_clean();
include __DIR__ . '/../layout/admin.php';
?> 