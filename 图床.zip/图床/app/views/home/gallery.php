<?php
ob_start();
?>

<div class="row mb-4">
    <div class="col-12">
        <div class="text-center">
            <h2 class="fw-bold text-white mb-3">图片画廊</h2>
            <p class="text-white-50">浏览所有公开的精彩图片</p>
        </div>
    </div>
</div>

<?php if (empty($images)): ?>
    <div class="row">
        <div class="col-12">
            <div class="card text-center">
                <div class="card-body py-5">
                    <i class="fas fa-images fa-3x text-muted mb-3"></i>
                    <h5>还没有图片</h5>
                    <p class="text-muted">成为第一个上传图片的用户吧！</p>
                    <a href="/index.php" class="btn btn-primary">
                        <i class="fas fa-upload me-2"></i>
                        立即上传
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <!-- 图片网格 -->
    <div class="image-grid">
        <?php foreach ($images as $image): ?>
            <div class="image-card">
                <img src="<?= htmlspecialchars($image['url']) ?>" 
                     alt="<?= htmlspecialchars($image['original_name']) ?>"
                     loading="lazy">
                <div class="image-overlay">
                    <h6 class="mb-2"><?= htmlspecialchars($image['original_name']) ?></h6>
                    <p class="mb-2 small">
                        <i class="fas fa-eye me-1"></i><?= number_format($image['views']) ?> 次浏览<br>
                        <i class="fas fa-clock me-1"></i><?= $image['upload_time'] ?><br>
                        <i class="fas fa-hdd me-1"></i><?= $image['formatted_size'] ?>
                    </p>
                    <?php if ($image['username']): ?>
                        <p class="mb-2 small">
                            <i class="fas fa-user me-1"></i><?= htmlspecialchars($image['username']) ?>
                        </p>
                    <?php else: ?>
                        <p class="mb-2 small">
                            <i class="fas fa-user-secret me-1"></i>游客上传
                        </p>
                    <?php endif; ?>
                    <div class="d-flex gap-1 justify-content-center">
                        <a href="/index.php?action=view&id=<?= $image['id'] ?>" 
                           class="btn btn-sm btn-primary">
                            <i class="fas fa-eye"></i>
                        </a>
                        <button class="btn btn-sm btn-success" 
                                onclick="copyToClipboard('<?= htmlspecialchars($image['url']) ?>')">
                            <i class="fas fa-copy"></i>
                        </button>
                        <a href="<?= htmlspecialchars($image['url']) ?>" 
                           target="_blank" class="btn btn-sm btn-info">
                            <i class="fas fa-external-link-alt"></i>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- 分页导航 -->
    <?php if ($pagination['total'] > 1): ?>
        <nav class="mt-5">
            <ul class="pagination justify-content-center">
                <?php if ($pagination['prev']): ?>
                    <li class="page-item">
                        <a class="page-link" href="?action=gallery&page=<?= $pagination['prev'] ?>">
                            <i class="fas fa-chevron-left me-1"></i>上一页
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php 
                $start = max(1, $pagination['current'] - 2);
                $end = min($pagination['total'], $pagination['current'] + 2);
                ?>
                
                <?php if ($start > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?action=gallery&page=1">1</a>
                    </li>
                    <?php if ($start > 2): ?>
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                
                <?php for ($i = $start; $i <= $end; $i++): ?>
                    <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                        <?php if ($i == $pagination['current']): ?>
                            <span class="page-link"><?= $i ?></span>
                        <?php else: ?>
                            <a class="page-link" href="?action=gallery&page=<?= $i ?>"><?= $i ?></a>
                        <?php endif; ?>
                    </li>
                <?php endfor; ?>
                
                <?php if ($end < $pagination['total']): ?>
                    <?php if ($end < $pagination['total'] - 1): ?>
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                    <?php endif; ?>
                    <li class="page-item">
                        <a class="page-link" href="?action=gallery&page=<?= $pagination['total'] ?>"><?= $pagination['total'] ?></a>
                    </li>
                <?php endif; ?>
                
                <?php if ($pagination['next']): ?>
                    <li class="page-item">
                        <a class="page-link" href="?action=gallery&page=<?= $pagination['next'] ?>">
                            下一页<i class="fas fa-chevron-right ms-1"></i>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
        
        <div class="text-center mt-3">
            <small class="text-white-50">
                第 <?= $pagination['current'] ?> 页，共 <?= $pagination['total'] ?> 页
            </small>
        </div>
    <?php endif; ?>
<?php endif; ?>

<!-- 返回顶部按钮 -->
<button id="backToTop" class="btn btn-primary position-fixed" 
        style="bottom: 2rem; right: 2rem; z-index: 1000; display: none; border-radius: 50%; width: 50px; height: 50px;">
    <i class="fas fa-chevron-up"></i>
</button>

<?php
$additionalJS = '
<script>
document.addEventListener("DOMContentLoaded", function() {
    const backToTopBtn = document.getElementById("backToTop");
    
    // 滚动显示返回顶部按钮
    window.addEventListener("scroll", function() {
        if (window.pageYOffset > 300) {
            backToTopBtn.style.display = "block";
        } else {
            backToTopBtn.style.display = "none";
        }
    });
    
    // 返回顶部
    backToTopBtn.addEventListener("click", function() {
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    });
    
    // 图片懒加载增强
    const images = document.querySelectorAll("img[loading=lazy]");
    
    if ("IntersectionObserver" in window) {
        const imageObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(function(entry) {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.src; // 触发加载
                    img.classList.add("loaded");
                    imageObserver.unobserve(img);
                }
            });
        });
        
        images.forEach(function(img) {
            imageObserver.observe(img);
        });
    }
});
</script>
';

$content = ob_get_clean();
include __DIR__ . '/../layout/base.php';
?> 