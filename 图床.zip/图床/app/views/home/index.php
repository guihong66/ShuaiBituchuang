<?php
ob_start();
?>

<!-- 主标题和描述 -->
<div class="text-center mb-5">
    <h1 class="display-4 fw-bold text-white mb-4"><?= htmlspecialchars($title) ?></h1>
    <div class="typewriter text-white fs-4 mb-4" id="typewriter" style="min-height: 2em;">
        <span id="typewriter-text"></span>
    </div>
    <!-- 调试信息 -->
    <div style="display: none;">
        调试: description = "<?= htmlspecialchars($description ?? 'UNDEFINED') ?>"
    </div>
</div>

<!-- 公告区域 -->
<?php if ($homeNotice && $homeNotice['is_active'] && !empty(trim($homeNotice['content']))): ?>
    <div class="row justify-content-center mb-4">
        <div class="col-md-8">
            <?= $homeNotice['content'] ?>
        </div>
    </div>
<?php endif; ?>

<!-- 上传区域 -->
<?php if ($allowGuestUpload || $currentUser): ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title text-center mb-4">
                        <i class="fas fa-cloud-upload-alt me-2"></i>
                        上传图片
                    </h5>
                    
                    <form id="uploadForm" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken) ?>">
                        
                        <div class="upload-area" id="uploadArea">
                            <div class="upload-icon mb-3">
                                <i class="fas fa-cloud-upload-alt fa-3x text-muted"></i>
                            </div>
                            <h6 class="mb-2">点击选择文件或拖拽到此处</h6>
                            <p class="text-muted mb-3">
                                支持格式: <?= htmlspecialchars($allowedExtensions) ?><br>
                                最大文件大小: <?= htmlspecialchars($maxFileSize) ?><br>
                                <small><i class="fas fa-info-circle me-1"></i>选择文件后可预览并确认上传</small>
                            </p>
                            <input type="file" name="image" id="imageInput" accept="image/*" style="display: none;">
                            
                            <!-- 格式转换选择 -->
                            <div class="mb-3">
                                <label class="form-label small">输出格式 (可选)</label>
                                <select class="form-select form-select-sm" name="convert_format" id="convertFormat">
                                    <option value="">保持原格式</option>
                                    <option value="jpg">JPG (适合照片)</option>
                                    <option value="png">PNG (透明背景)</option>
                                    <option value="webp">WebP (更小文件)</option>
                                </select>
                            </div>
                            
                            <button type="button" class="btn btn-primary" onclick="document.getElementById('imageInput').click()">
                                <i class="fas fa-folder-open me-2"></i>选择文件
                            </button>
                        </div>
                        
                        <div id="uploadResult" class="mt-4" style="display: none;"></div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <!-- 未登录提示 -->
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-lock fa-3x text-muted mb-3"></i>
                    <h5 class="card-title">需要登录</h5>
                    <p class="card-text text-muted">请先登录后再上传图片</p>
                    <a href="/login.php" class="btn btn-primary">
                        <i class="fas fa-sign-in-alt me-2"></i>立即登录
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- 最近上传 -->
<div class="row mt-5">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">
                    <i class="fas fa-clock me-2"></i>
                    最近上传
                </h5>
                <p class="text-muted">查看更多精彩图片</p>
                <div class="text-center">
                    <?php if ($gallery_enabled): ?>
                        <a href="/index.php?action=gallery" class="btn btn-outline-primary">
                            <i class="fas fa-images me-2"></i>浏览画廊
                        </a>
                    <?php else: ?>
                        <button class="btn btn-outline-secondary" disabled>
                            <i class="fas fa-lock me-2"></i>画廊已关闭
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 附加JavaScript -->
<script>
// 循环打字机效果
document.addEventListener("DOMContentLoaded", function() {
    const typewriterElement = document.getElementById("typewriter-text");
    
    // 从配置中获取打字机设置
    const typewriterEnabled = <?= json_encode($this->config->getBool('typewriter_enabled', true)) ?>;
    const description = <?= json_encode($description ?? '简单、快速、稳定的图片存储服务') ?>;
    const typewriterSpeed = <?= (int)($this->config->get('typewriter_speed', 100)) ?>;
    
    if (!typewriterElement || !typewriterEnabled) {
        // 如果打字机功能被禁用，直接显示描述文字
        if (typewriterElement && description) {
            typewriterElement.textContent = description;
        }
        return;
    }
    
    if (!description || description.trim() === '') {
        console.error("打字机描述为空");
        return;
    }
    
    let charIndex = 0;
    let isDeleting = false;
    
    function typeEffect() {
    if (isDeleting) {
            typewriterElement.textContent = description.substring(0, charIndex - 1);
        charIndex--;
    } else {
            typewriterElement.textContent = description.substring(0, charIndex + 1);
        charIndex++;
    }
    
        let speed = isDeleting ? Math.max(typewriterSpeed / 2, 25) : typewriterSpeed;
    
    if (!isDeleting && charIndex === description.length) {
            speed = 2000; // 停留2秒
        isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
            speed = 1000; // 停留1秒
    }
    
    setTimeout(typeEffect, speed);
}

    // 开始打字机效果
                typeEffect();
});

// 上传功能
document.addEventListener("DOMContentLoaded", function() {
const uploadArea = document.getElementById("uploadArea");
const imageInput = document.getElementById("imageInput");
const uploadForm = document.getElementById("uploadForm");
const uploadResult = document.getElementById("uploadResult");
    
    if (!uploadArea || !imageInput || !uploadResult) return;

// 点击上传区域选择文件
uploadArea.addEventListener("click", function(e) {
    if (e.target.tagName !== "BUTTON") {
        imageInput.click();
    }
});

// 拖拽上传
uploadArea.addEventListener("dragover", function(e) {
    e.preventDefault();
    uploadArea.classList.add("dragover");
});

uploadArea.addEventListener("dragleave", function(e) {
    e.preventDefault();
    uploadArea.classList.remove("dragover");
});

uploadArea.addEventListener("drop", function(e) {
    e.preventDefault();
    uploadArea.classList.remove("dragover");
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        imageInput.files = files;
        showUploadPreview(files[0]);
    }
});

// 文件选择事件
imageInput.addEventListener("change", function() {
    if (this.files.length > 0) {
        showUploadPreview(this.files[0]);
    }
});

}); // 结束DOMContentLoaded

// 全局函数 - 重置上传
function resetUpload() {
    const uploadResult = document.getElementById("uploadResult");
    const imageInput = document.getElementById("imageInput");
    if (uploadResult) {
        uploadResult.style.display = "none";
        uploadResult.innerHTML = "";
    }
    if (imageInput) {
        imageInput.value = "";
    }
}

// 全局函数 - 上传文件
function uploadFile() {
    const imageInput = document.getElementById("imageInput");
    const uploadResult = document.getElementById("uploadResult");
    const file = imageInput.files[0];
    if (!file) return;
    
    // 显示上传进度状态
    showUploadProgress(file);
    
    // 创建FormData
    const formData = new FormData();
    formData.append("csrf_token", window.csrfToken);
    formData.append("image", file);
    
    // 添加格式转换选项
    const convertFormat = document.getElementById("convertFormat").value;
    if (convertFormat) {
        formData.append("convert_format", convertFormat);
    }
    
    // 创建XMLHttpRequest
    const xhr = new XMLHttpRequest();
    
    // 上传进度
    xhr.upload.addEventListener("progress", function(e) {
        if (e.lengthComputable) {
            const percent = (e.loaded / e.total) * 100;
            const progressBar = uploadResult.querySelector('.progress-bar');
            if (progressBar) {
                progressBar.style.width = percent + '%';
                progressBar.textContent = Math.round(percent) + '%';
            }
        }
    });
    
    // 上传完成
    xhr.addEventListener("load", function() {
        try {
            const response = JSON.parse(xhr.responseText);
            if (xhr.status === 200 && response.success) {
                showUploadSuccess(response.data);
            } else {
                showUploadError(response.message || "上传失败");
            }
        } catch (e) {
            showUploadError("响应格式错误");
        }
    });
    
    // 上传错误
    xhr.addEventListener("error", function() {
        showUploadError("网络错误");
    });
    
    xhr.open("POST", "/index.php?action=upload", true);
    xhr.send(formData);
}

// 全局函数 - 显示上传预览
function showUploadPreview(file) {
    const uploadResult = document.getElementById("uploadResult");
    // 检查文件类型
    if (!file.type.startsWith('image/')) {
        showUploadError('请选择图片文件');
        return;
    }
    
    // 检查文件大小 (这里简单检查，具体限制以服务器为准)
    const maxSize = 50 * 1024 * 1024; // 50MB
    if (file.size > maxSize) {
        showUploadError('文件大小超出限制');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const convertFormat = document.getElementById("convertFormat").value;
        const formatText = convertFormat ? ` → ${convertFormat.toUpperCase()}` : '';
        
        uploadResult.innerHTML = `
            <div class="upload-preview">
                <div class="text-center mb-3">
                    <img src="${e.target.result}" alt="预览" style="max-width: 300px; max-height: 300px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
                </div>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>文件信息:</strong><br>
                    文件名: ${file.name}<br>
                    大小: ${(file.size / 1024 / 1024).toFixed(2)} MB<br>
                    类型: ${file.type}${formatText}
                </div>
                <div class="d-flex justify-content-center gap-2">
                    <button type="button" class="btn btn-success" onclick="confirmUpload()">
                        <i class="fas fa-cloud-upload-alt me-2"></i>确认上传
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="cancelUpload()">
                        <i class="fas fa-times me-2"></i>取消
                    </button>
                </div>
            </div>
        `;
        uploadResult.style.display = "block";
    };
    reader.readAsDataURL(file);
}



// 显示上传进度
function showUploadProgress(file) {
    uploadResult.innerHTML = `
        <div class="upload-progress">
            <div class="text-center mb-3">
                <img src="${URL.createObjectURL(file)}" alt="上传中" style="max-width: 200px; max-height: 200px; border-radius: 10px; opacity: 0.8;">
            </div>
            <div class="alert alert-warning">
                <i class="fas fa-spinner fa-spin me-2"></i>
                正在上传: ${file.name}
            </div>
            <div class="progress mb-3">
                <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%"></div>
            </div>
            <div class="text-center">
                <small class="text-muted">请稍候，正在处理您的图片...</small>
            </div>
        </div>
    `;
}

// 显示上传成功
function showUploadSuccess(data) {
    uploadResult.innerHTML = `
        <div class="upload-success">
            <div class="text-center mb-3">
                <img src="${data.url}" alt="上传成功" style="max-width: 200px; max-height: 200px; border-radius: 10px;">
            </div>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i>
                上传成功！${data.converted_format ? ` (已转换为 ${data.converted_format.toUpperCase()} 格式)` : ''}
            </div>
            <div class="input-group mb-2">
                <span class="input-group-text">直链地址</span>
                <input type="text" class="form-control" value="${data.url}" readonly>
                <button class="btn btn-outline-secondary" type="button" onclick="copyToClipboard('${data.url}')">
                    <i class="fas fa-copy"></i>
                </button>
            </div>
            <div class="input-group mb-2">
                <span class="input-group-text">HTML代码</span>
                <input type="text" class="form-control" value="&lt;img src=&quot;${data.url}&quot; alt=&quot;${data.original_name}&quot;&gt;" readonly>
                <button class="btn btn-outline-secondary" type="button" onclick="copyToClipboard('<img src=&quot;${data.url}&quot; alt=&quot;${data.original_name}&quot;>')">
                    <i class="fas fa-copy"></i>
                </button>
            </div>
            <div class="input-group mb-2">
                <span class="input-group-text">Markdown</span>
                <input type="text" class="form-control" value="![${data.original_name}](${data.url})" readonly>
                <button class="btn btn-outline-secondary" type="button" onclick="copyToClipboard('![${data.original_name}](${data.url})')">
                    <i class="fas fa-copy"></i>
                </button>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text">论坛代码</span>
                <input type="text" class="form-control" value="[img]${data.url}[/img]" readonly>
                <button class="btn btn-outline-secondary" type="button" onclick="copyToClipboard('[img]${data.url}[/img]')">
                    <i class="fas fa-copy"></i>
                </button>
            </div>
            <div class="text-center">
                <a href="/index.php?action=view&id=${data.id}" class="btn btn-primary me-2">
                    <i class="fas fa-eye me-2"></i>查看详情
                </a>
                <button class="btn btn-secondary" onclick="resetUpload()">
                    <i class="fas fa-plus me-2"></i>继续上传
                </button>
            </div>
        </div>
    `;
}

// 显示上传错误
function showUploadError(message) {
    uploadResult.innerHTML = `
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle me-2"></i>
            ${message}
        </div>
        <div class="text-center">
            <button class="btn btn-secondary" onclick="resetUpload()">
                <i class="fas fa-redo me-2"></i>重新上传
            </button>
        </div>
    `;
}



// 全局函数 - 确认上传
function confirmUpload() {
    const imageInput = document.getElementById("imageInput");
    if (imageInput && imageInput.files.length > 0) {
        uploadFile();
    }
}

// 全局函数 - 取消上传
function cancelUpload() {
    resetUpload();
}
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/base.php';
?> 