<?php
ob_start();
?>

<div class="row justify-content-center">
    <div class="col-md-8 col-lg-6">
        <div class="card text-center shadow-lg">
            <div class="card-body py-5">
                <div class="mb-4">
                    <i class="fas fa-images fa-4x text-muted"></i>
                </div>
                <h3 class="card-title text-muted mb-3">画廊已关闭</h3>
                <p class="card-text text-muted mb-4">
                    <?= htmlspecialchars($message) ?>，暂时无法访问图片画廊。
                </p>
                <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                    <a href="<?= $_SERVER['HTTP_REFERER'] ?? '/index.php' ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i>
                        返回上页
                    </a>
                    <a href="/index.php" class="btn btn-primary">
                        <i class="fas fa-home me-2"></i>
                        回到首页
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border: none;
    border-radius: 15px;
}

.fa-images {
    opacity: 0.3;
}
</style>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/base.php';
?> 