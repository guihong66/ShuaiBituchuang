<?php
ob_start();
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-body text-center">
                <!-- 图片显示 -->
                <div class="mb-4">
                    <img src="<?= htmlspecialchars($image['url']) ?>" 
                         alt="<?= htmlspecialchars($image['original_name']) ?>"
                         class="img-fluid rounded shadow"
                         style="max-width: 100%; max-height: 600px;">
                </div>

                <!-- 图片信息 -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <h5 class="mb-3"><?= htmlspecialchars($image['original_name']) ?></h5>
                        <div class="list-group list-group-flush">
                            <div class="list-group-item d-flex justify-content-between">
                                <strong>文件大小:</strong>
                                <span><?= $formattedSize ?></span>
                            </div>
                            <div class="list-group-item d-flex justify-content-between">
                                <strong>文件类型:</strong>
                                <span><?= htmlspecialchars($image['mime_type']) ?></span>
                            </div>
                            <?php if ($image['width'] && $image['height']): ?>
                                <div class="list-group-item d-flex justify-content-between">
                                    <strong>图片尺寸:</strong>
                                    <span><?= $image['width'] ?> × <?= $image['height'] ?></span>
                                </div>
                            <?php endif; ?>
                            <div class="list-group-item d-flex justify-content-between">
                                <strong>浏览次数:</strong>
                                <span><?= number_format($image['views']) ?></span>
                            </div>
                            <div class="list-group-item d-flex justify-content-between">
                                <strong>上传时间:</strong>
                                <span><?= $uploadTime ?></span>
                            </div>
                            <?php if ($uploader): ?>
                                <div class="list-group-item d-flex justify-content-between">
                                    <strong>上传者:</strong>
                                    <span><?= htmlspecialchars($uploader['username']) ?></span>
                                </div>
                            <?php else: ?>
                                <div class="list-group-item d-flex justify-content-between">
                                    <strong>上传者:</strong>
                                    <span class="text-muted">游客</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h6 class="mb-3">图片链接</h6>
                        
                        <!-- 直链地址 -->
                        <div class="mb-3">
                            <label class="form-label small">直链地址</label>
                            <div class="input-group">
                                <input type="text" class="form-control" value="<?= htmlspecialchars($image['url']) ?>" readonly>
                                <button class="btn btn-outline-secondary" type="button" 
                                        onclick="copyToClipboard('<?= htmlspecialchars($image['url']) ?>')">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                        </div>

                        <!-- HTML代码 -->
                        <div class="mb-3">
                            <label class="form-label small">HTML代码</label>
                            <div class="input-group">
                                <input type="text" class="form-control" 
                                       value="&lt;img src=&quot;<?= htmlspecialchars($image['url']) ?>&quot; alt=&quot;<?= htmlspecialchars($image['original_name']) ?>&quot;&gt;" readonly>
                                <button class="btn btn-outline-secondary" type="button" 
                                        onclick="copyToClipboard('<img src=&quot;<?= htmlspecialchars($image['url']) ?>&quot; alt=&quot;<?= htmlspecialchars($image['original_name']) ?>&quot;>')">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Markdown代码 -->
                        <div class="mb-3">
                            <label class="form-label small">Markdown</label>
                            <div class="input-group">
                                <input type="text" class="form-control" 
                                       value="![<?= htmlspecialchars($image['original_name']) ?>](<?= htmlspecialchars($image['url']) ?>)" readonly>
                                <button class="btn btn-outline-secondary" type="button" 
                                        onclick="copyToClipboard('![<?= htmlspecialchars($image['original_name']) ?>](<?= htmlspecialchars($image['url']) ?>)')">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                        </div>

                        <!-- 论坛代码 -->
                        <div class="mb-3">
                            <label class="form-label small">论坛代码</label>
                            <div class="input-group">
                                <input type="text" class="form-control" 
                                       value="[img]<?= htmlspecialchars($image['url']) ?>[/img]" readonly>
                                <button class="btn btn-outline-secondary" type="button" 
                                        onclick="copyToClipboard('[img]<?= htmlspecialchars($image['url']) ?>[/img]')">
                                    <i class="fas fa-copy"></i>
                                </button>
                            </div>
                        </div>

                        <!-- 多格式链接 -->
                        <?php if (!empty($formatLinks)): ?>
                            <h6 class="mt-4 mb-3">其他格式链接</h6>
                            <?php foreach ($formatLinks as $format => $link): ?>
                                <?php if (!$link['current']): ?>
                                    <div class="mb-2">
                                        <label class="form-label small"><?= strtoupper($format) ?> 格式</label>
                                        <div class="input-group">
                                            <?php if ($link['available']): ?>
                                                <input type="text" class="form-control" 
                                                       value="<?= htmlspecialchars($link['url']) ?>" readonly>
                                                <button class="btn btn-outline-secondary" type="button" 
                                                        onclick="copyToClipboard('<?= htmlspecialchars($link['url']) ?>')">
                                                    <i class="fas fa-copy"></i>
                                                </button>
                                            <?php else: ?>
                                                <input type="text" class="form-control" 
                                                       value="点击生成<?= strtoupper($format) ?>格式" readonly>
                                                <button class="btn btn-outline-primary" type="button" 
                                                        onclick="convertImageFormat(<?= $image['id'] ?>, '<?= $format ?>')">
                                                    <i class="fas fa-magic"></i> 生成
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- 操作按钮 -->
                <div class="d-flex justify-content-center gap-2 flex-wrap">
                    <a href="<?= htmlspecialchars($image['url']) ?>" target="_blank" class="btn btn-primary">
                        <i class="fas fa-external-link-alt me-2"></i>
                        原图查看
                    </a>
                    <a href="<?= htmlspecialchars($image['url']) ?>" download="<?= htmlspecialchars($image['original_name']) ?>" 
                       class="btn btn-success">
                        <i class="fas fa-download me-2"></i>
                        下载图片
                    </a>
                    <a href="/index.php?action=gallery" class="btn btn-outline-info">
                        <i class="fas fa-images me-2"></i>
                        浏览更多
                    </a>
                    <a href="/index.php" class="btn btn-outline-secondary">
                        <i class="fas fa-home me-2"></i>
                        返回首页
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$additionalJS = '
<script>
// 格式转换功能
function convertImageFormat(imageId, targetFormat) {
    if (!window.csrfToken) {
        showMessage("系统错误：缺少安全令牌", "danger");
        return;
    }
    
    // 禁用按钮，显示加载状态
    const button = event.target.closest("button");
    const originalContent = button.innerHTML;
    button.disabled = true;
    button.innerHTML = `<span class="spinner-border spinner-border-sm me-1"></span>生成中...`;
    
    fetch("/index.php?action=convert", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: `csrf_token=${encodeURIComponent(window.csrfToken)}&image_id=${imageId}&target_format=${targetFormat}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showMessage(data.message, "success");
            // 更新输入框和按钮
            const inputGroup = button.closest(".input-group");
            const input = inputGroup.querySelector("input");
            input.value = data.url;
            button.className = "btn btn-outline-secondary";
            button.innerHTML = `<i class="fas fa-copy"></i>`;
            button.onclick = function() { copyToClipboard(data.url); };
        } else {
            showMessage(data.message, "danger");
            button.disabled = false;
            button.innerHTML = originalContent;
        }
    })
    .catch(error => {
        showMessage("网络错误，请稍后再试", "danger");
        button.disabled = false;
        button.innerHTML = originalContent;
    });
}
</script>
';

$content = ob_get_clean();
include __DIR__ . '/../layout/base.php';
?> 