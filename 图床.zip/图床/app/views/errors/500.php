<?php
ob_start();
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card text-center">
            <div class="card-body py-5">
                <div class="error-number mb-4">
                    <h1 class="display-1 fw-bold text-warning">500</h1>
                </div>
                <h3 class="mb-3">服务器错误</h3>
                <p class="text-muted mb-4">
                    抱歉，服务器遇到了问题。请稍后再试，如果问题持续存在，请联系管理员。
                </p>
                <?php if (isset($message)): ?>
                    <div class="alert alert-danger">
                        <?= htmlspecialchars($message) ?>
                    </div>
                <?php endif; ?>
                <div>
                    <a href="/index.php" class="btn btn-primary me-2">
                        <i class="fas fa-home me-2"></i>返回首页
                    </a>
                    <button class="btn btn-outline-secondary" onclick="location.reload()">
                        <i class="fas fa-redo me-2"></i>刷新页面
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/base.php';
?> 