<?php
ob_start();
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card text-center">
            <div class="card-body py-5">
                <div class="error-number mb-4">
                    <h1 class="display-1 fw-bold text-danger">403</h1>
                </div>
                <h3 class="mb-3">访问被拒绝</h3>
                <p class="text-muted mb-4">
                    抱歉，您没有权限访问此页面。请联系管理员或使用其他账号登录。
                </p>
                <div>
                    <a href="/index.php" class="btn btn-primary me-2">
                        <i class="fas fa-home me-2"></i>返回首页
                    </a>
                    <a href="/login.php" class="btn btn-outline-primary">
                        <i class="fas fa-sign-in-alt me-2"></i>重新登录
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/base.php';
?> 