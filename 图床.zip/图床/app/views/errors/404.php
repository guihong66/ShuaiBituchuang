<?php
ob_start();
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card text-center">
            <div class="card-body py-5">
                <div class="error-number mb-4">
                    <h1 class="display-1 fw-bold text-primary">404</h1>
                </div>
                <h3 class="mb-3">页面未找到</h3>
                <p class="text-muted mb-4">
                    抱歉，您访问的页面不存在。可能是链接错误或页面已被删除。
                </p>
                <div>
                    <a href="/index.php" class="btn btn-primary me-2">
                        <i class="fas fa-home me-2"></i>返回首页
                    </a>
                    <button class="btn btn-outline-secondary" onclick="history.back()">
                        <i class="fas fa-arrow-left me-2"></i>返回上页
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layout/base.php';
?> 