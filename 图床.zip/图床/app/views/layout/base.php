<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title ?? $siteInfo['name']) ?><?= htmlspecialchars($siteInfo['title_suffix']) ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <!-- 自定义样式 -->
    <style>
        :root {
            --primary-color: #667eea;
            --secondary-color: #764ba2;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
        }

        <?php 
        $backgroundImage = $config->get('background_image', '');
        if (!empty($backgroundImage)): ?>
        body {
            font-family: 'Arial', 'Microsoft YaHei', sans-serif;
            background: url('<?= htmlspecialchars($backgroundImage) ?>') center/cover no-repeat fixed;
            min-height: 100vh;
            position: relative;
        }
        <?php else: ?>
        body {
            font-family: 'Arial', 'Microsoft YaHei', sans-serif;
            background: linear-gradient(135deg, #2C3E50 0%, #4A6741 30%, #34495E 60%, #2C3E50 100%);
            min-height: 100vh;
            position: relative;
        }
        <?php endif; ?>

        .navbar {
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95) !important;
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
        }

        .main-content {
            margin-top: 2rem;
            margin-bottom: 2rem;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
        }

        .btn-primary {
            background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
            border: none;
            border-radius: 25px;
            padding: 10px 25px;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        }

        .typewriter {
            min-height: 2em;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        
        .typewriter::after {
            content: '|';
            animation: blink-caret 1s step-end infinite;
            color: var(--primary-color);
            font-weight: 100;
        }

        @keyframes blink-caret {
            from, to { opacity: 1 }
            50% { opacity: 0 }
        }

        .upload-area {
            border: 2px dashed #dee2e6;
            border-radius: 10px;
            padding: 3rem;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .upload-area:hover, .upload-area.dragover {
            border-color: var(--primary-color);
            background: rgba(102, 126, 234, 0.05);
        }

        .upload-preview, .upload-progress {
            animation: fadeIn 0.3s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .upload-preview .btn {
            min-width: 120px;
        }



        .image-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-top: 2rem;
        }

        .image-card {
            position: relative;
            border-radius: 10px;
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        .image-card:hover {
            transform: translateY(-5px);
        }

        .image-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .image-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(transparent, rgba(0,0,0,0.7));
            color: white;
            padding: 1rem;
            transform: translateY(100%);
            transition: transform 0.3s ease;
        }

        .image-card:hover .image-overlay {
            transform: translateY(0);
        }

        .progress-container {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 9999;
        }

        .footer {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            color: white;
            padding: 2rem 0;
            margin-top: auto;
        }

        .alert {
            border: none;
            border-radius: 10px;
        }

        @media (max-width: 768px) {
            .typewriter {
                font-size: 1.2rem;
            }
            
            .upload-area {
                padding: 2rem 1rem;
            }
            
            .image-grid {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
                gap: 1rem;
            }
        }
    </style>
    
    <?php if (isset($additionalCSS)): ?>
        <?= $additionalCSS ?>
    <?php endif; ?>
</head>
<body>

    
    <!-- 导航栏 -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand fw-bold" href="/index.php">
                <i class="fas fa-cloud-upload-alt me-2"></i>
                <?= htmlspecialchars($siteInfo['name']) ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/index.php">
                            <i class="fas fa-home me-1"></i>首页
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/index.php?action=gallery">
                            <i class="fas fa-images me-1"></i>画廊
                        </a>
                    </li>
                </ul>
                
                <ul class="navbar-nav">
                    <?php if ($currentUser): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user me-1"></i>
                                <?= htmlspecialchars($currentUser['username']) ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="/profile.php">
                                    <i class="fas fa-user-cog me-2"></i>个人中心
                                </a></li>
                                <?php if ($currentUser['role'] === 'admin'): ?>
                                    <li><a class="dropdown-item" href="/admin/">
                                        <i class="fas fa-cogs me-2"></i>管理后台
                                    </a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="/logout.php">
                                    <i class="fas fa-sign-out-alt me-2"></i>退出登录
                                </a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/login.php">
                                <i class="fas fa-sign-in-alt me-1"></i>登录
                            </a>
                        </li>
                        <?php if ($uploadConfig['allow_guest_upload'] || isset($allowRegistration) && $allowRegistration): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="/register.php">
                                    <i class="fas fa-user-plus me-1"></i>注册
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- 进度条容器 -->
    <div class="progress-container" id="progressContainer" style="display: none;">
        <div class="progress" style="height: 4px; border-radius: 0;">
            <div class="progress-bar" role="progressbar" style="width: 0%"></div>
        </div>
    </div>

    <!-- 主要内容 -->
    <div class="container main-content">
        <?php if (isset($content)): ?>
            <?= $content ?>
        <?php endif; ?>
    </div>

    <!-- 页脚 -->
    <footer class="footer mt-auto">
        <div class="container text-center">
            <p class="mb-1">&copy; <?= date('Y') ?> <?= htmlspecialchars($siteInfo['name']) ?>. 保留所有权利.</p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- 通用JavaScript -->
    <script>
        // 全局CSRF令牌
        window.csrfToken = '<?= $csrfToken ?? '' ?>';
        
        // 通用AJAX函数
        function ajaxRequest(url, data, onSuccess, onError) {
            const xhr = new XMLHttpRequest();
            const formData = new FormData();
            
            // 添加CSRF令牌
            if (window.csrfToken) {
                formData.append('csrf_token', window.csrfToken);
            }
            
            // 添加其他数据
            for (const key in data) {
                formData.append(key, data[key]);
            }
            
            xhr.open('POST', url, true);
            
            xhr.onload = function() {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (xhr.status === 200 && response.success) {
                        onSuccess(response);
                    } else {
                        onError(response.message || '请求失败');
                    }
                } catch (e) {
                    onError('响应格式错误');
                }
            };
            
            xhr.onerror = function() {
                onError('网络错误');
            };
            
            xhr.send(formData);
        }
        
        // 显示消息
        function showMessage(message, type = 'info') {
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
            alertDiv.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            const container = document.querySelector('.main-content');
            container.insertBefore(alertDiv, container.firstChild);
            
            // 5秒后自动消失
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    alertDiv.remove();
                }
            }, 5000);
        }
        
        // 显示进度条
        function showProgress(percent) {
            const container = document.getElementById('progressContainer');
            const bar = container.querySelector('.progress-bar');
            
            if (percent <= 0) {
                container.style.display = 'none';
            } else {
                container.style.display = 'block';
                bar.style.width = percent + '%';
                
                if (percent >= 100) {
                    setTimeout(() => {
                        container.style.display = 'none';
                        bar.style.width = '0%';
                    }, 1000);
                }
            }
        }
        
        // 复制到剪贴板
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                showMessage('已复制到剪贴板', 'success');
            }).catch(() => {
                showMessage('复制失败', 'danger');
            });
        }
        

    </script>
    
    <!-- 樱花飘落效果 -->
    <?php if ($config->getBool('sakura_enabled', false)): ?>
    <script src="https://jsd.cdn.zzko.cn/gh/lizina66/api/img/jpuer.js"></script>
    <?php endif; ?>
    
    <?php if (isset($additionalJS)): ?>
        <?= $additionalJS ?>
    <?php endif; ?>
</body>
</html> 