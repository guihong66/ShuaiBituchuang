<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title ?? '管理后台') ?> - <?= htmlspecialchars($siteInfo['name']) ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <!-- 管理后台样式 -->
    <style>
        :root {
            --admin-primary: #2c3e50;
            --admin-secondary: #3498db;
            --admin-success: #27ae60;
            --admin-danger: #e74c3c;
            --admin-warning: #f39c12;
            --admin-info: #17a2b8;
            --sidebar-width: 250px;
        }

        body {
            font-family: 'Arial', 'Microsoft YaHei', sans-serif;
            background-color: #f8f9fa;
        }

        .admin-wrapper {
            display: flex;
            min-height: 100vh;
        }

        .admin-sidebar {
            width: var(--sidebar-width);
            background: var(--admin-primary);
            color: white;
            padding: 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
        }

        .admin-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            padding: 0;
        }

        .admin-header {
            background: white;
            border-bottom: 1px solid #dee2e6;
            padding: 1rem 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .admin-main {
            padding: 2rem;
        }

        .sidebar-brand {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }

        .sidebar-brand h4 {
            margin: 0;
            font-weight: bold;
        }

        .sidebar-nav {
            padding: 1rem 0;
        }

        .nav-item {
            margin: 0.2rem 0;
        }

        .nav-link {
            color: rgba(255,255,255,0.8);
            padding: 0.75rem 1.5rem;
            border-radius: 0;
            transition: all 0.3s ease;
            border: none;
            text-decoration: none;
        }

        .nav-link:hover,
        .nav-link.active {
            color: white;
            background: rgba(255,255,255,0.1);
        }

        .nav-link i {
            width: 20px;
            margin-right: 0.5rem;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .card-header {
            background: white;
            border-bottom: 1px solid #f0f0f0;
            padding: 1.25rem;
            border-radius: 10px 10px 0 0 !important;
        }

        .stat-card {
            background: linear-gradient(135deg, var(--admin-secondary), #5dade2);
            color: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 1rem;
        }

        .stat-card.success {
            background: linear-gradient(135deg, var(--admin-success), #58d68d);
        }

        .stat-card.danger {
            background: linear-gradient(135deg, var(--admin-danger), #ec7063);
        }

        .stat-card.warning {
            background: linear-gradient(135deg, var(--admin-warning), #f7dc6f);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }

        .table {
            border-radius: 10px;
            overflow: hidden;
        }

        .table thead th {
            background: var(--admin-primary);
            color: white;
            border: none;
            font-weight: 500;
        }

        .btn-admin {
            border-radius: 25px;
            padding: 8px 20px;
            font-weight: 500;
        }

        .badge-status {
            padding: 0.4em 0.8em;
            border-radius: 15px;
        }

        .image-thumb {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: var(--admin-secondary);
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }

        .alert {
            border: none;
            border-radius: 10px;
        }

        @media (max-width: 768px) {
            .admin-sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .admin-sidebar.show {
                transform: translateX(0);
            }
            
            .admin-content {
                margin-left: 0;
            }
            
            .admin-header {
                padding: 1rem;
            }
            
            .admin-main {
                padding: 1rem;
            }
        }

        .sidebar-toggle {
            display: none;
        }

        @media (max-width: 768px) {
            .sidebar-toggle {
                display: inline-block;
            }
        }
    </style>
    
    <?php if (isset($additionalCSS)): ?>
        <?= $additionalCSS ?>
    <?php endif; ?>
</head>
<body>
    <div class="admin-wrapper">
        <!-- 侧边栏 -->
        <div class="admin-sidebar" id="adminSidebar">
            <div class="sidebar-brand">
                <h4>
                    <i class="fas fa-cogs me-2"></i>
                    管理后台
                </h4>
            </div>
            
            <nav class="sidebar-nav">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?= ($_GET['action'] ?? 'dashboard') === 'dashboard' ? 'active' : '' ?>" 
                           href="/admin/?action=dashboard">
                            <i class="fas fa-tachometer-alt"></i>
                            仪表板
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($_GET['action'] ?? '') === 'users' ? 'active' : '' ?>" 
                           href="/admin/?action=users">
                            <i class="fas fa-users"></i>
                            用户管理
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($_GET['action'] ?? '') === 'images' ? 'active' : '' ?>" 
                           href="/admin/?action=images">
                            <i class="fas fa-images"></i>
                            图片管理
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($_GET['action'] ?? '') === 'settings' ? 'active' : '' ?>" 
                           href="/admin/?action=settings">
                            <i class="fas fa-cog"></i>
                            系统设置
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($_GET['action'] ?? '') === 'notices' ? 'active' : '' ?>" 
                           href="/admin/?action=notices">
                            <i class="fas fa-bullhorn"></i>
                            公告管理
                        </a>
                    </li>
                    <li class="nav-item mt-3 pt-3" style="border-top: 1px solid rgba(255,255,255,0.1);">
                        <a class="nav-link" href="/index.php">
                            <i class="fas fa-home"></i>
                            返回前台
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/logout.php">
                            <i class="fas fa-sign-out-alt"></i>
                            退出登录
                        </a>
                    </li>
                </ul>
            </nav>
        </div>

        <!-- 主要内容区域 -->
        <div class="admin-content">
            <!-- 顶部导航 -->
            <div class="admin-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <button class="btn btn-link sidebar-toggle me-3 d-lg-none" onclick="toggleSidebar()">
                            <i class="fas fa-bars"></i>
                        </button>
                        <h5 class="mb-0"><?= htmlspecialchars($title ?? '管理后台') ?></h5>
                    </div>
                    
                    <div class="d-flex align-items-center">
                        <span class="me-3">
                            <i class="fas fa-user-shield me-1"></i>
                            <?= htmlspecialchars($currentUser['username']) ?>
                        </span>
                        <small class="text-muted">
                            <?= date('Y-m-d H:i') ?>
                        </small>
                    </div>
                </div>
            </div>

            <!-- 主要内容 -->
            <div class="admin-main">
                <?php if (isset($content)): ?>
                    <?= $content ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- 管理后台通用脚本 -->
    <script>
        // 全局CSRF令牌
        window.csrfToken = '<?= $csrfToken ?? '' ?>';
        
        // 侧边栏切换
        function toggleSidebar() {
            const sidebar = document.getElementById('adminSidebar');
            sidebar.classList.toggle('show');
        }
        
        // 点击外部关闭侧边栏
        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('adminSidebar');
            const toggle = document.querySelector('.sidebar-toggle');
            
            if (window.innerWidth <= 768 && 
                !sidebar.contains(e.target) && 
                !toggle.contains(e.target)) {
                sidebar.classList.remove('show');
            }
        });
        
        // 通用AJAX函数
        function adminRequest(url, data, onSuccess, onError) {
            const xhr = new XMLHttpRequest();
            const formData = new FormData();
            
            // 添加CSRF令牌
            if (window.csrfToken) {
                formData.append('csrf_token', window.csrfToken);
            }
            
            // 添加其他数据
            for (const key in data) {
                formData.append(key, data[key]);
            }
            
            xhr.open('POST', url, true);
            
            xhr.onload = function() {
                try {
                    const response = JSON.parse(xhr.responseText);
                    if (xhr.status === 200 && response.success) {
                        onSuccess(response);
                    } else {
                        onError(response.message || '请求失败');
                    }
                } catch (e) {
                    onError('响应格式错误');
                }
            };
            
            xhr.onerror = function() {
                onError('网络错误');
            };
            
            xhr.send(formData);
        }
        
        // 显示消息
        function showAdminMessage(message, type = 'info') {
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
            alertDiv.innerHTML = `
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            const container = document.querySelector('.admin-main');
            container.insertBefore(alertDiv, container.firstChild);
            
            // 5秒后自动消失
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    alertDiv.remove();
                }
            }, 5000);
        }
        
        // 确认对话框
        function confirmAction(message, callback) {
            if (confirm(message)) {
                callback();
            }
        }
    </script>
    
    <?php if (isset($additionalJS)): ?>
        <?= $additionalJS ?>
    <?php endif; ?>
</body>
</html> 