<?php

class Database {
    private static $instance = null;
    private $connection;
    private $host;
    private $username;
    private $password;
    private $database;

    private function __construct() {
        // 构造函数私有化，防止直接实例化
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function connect($host, $username, $password, $database) {
        $this->host = $host;
        $this->username = $username;
        $this->password = $password;
        $this->database = $database;

        try {
            $this->connection = new PDO(
                "mysql:host={$host};dbname={$database};charset=utf8mb4",
                $username,
                $password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
            return true;
        } catch (PDOException $e) {
            throw new Exception("数据库连接失败: " . $e->getMessage());
        }
    }

    public function getConnection() {
        if ($this->connection === null) {
            // 尝试从配置文件读取数据库信息
            $this->loadFromConfig();
        }
        return $this->connection;
    }

    private function loadFromConfig() {
        $configFile = __DIR__ . '/../../config/database.php';
        if (file_exists($configFile)) {
            $config = require $configFile;
            $this->connect(
                $config['host'],
                $config['username'], 
                $config['password'],
                $config['database']
            );
        }
    }

    public function query($sql, $params = []) {
        try {
            $stmt = $this->getConnection()->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            throw new Exception("数据库查询失败: " . $e->getMessage());
        }
    }

    public function fetchAll($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }

    public function fetchOne($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetch();
    }

    public function insert($table, $data) {
        $columns = array_keys($data);
        $placeholders = ':' . implode(', :', $columns);
        $sql = "INSERT INTO {$table} (" . implode(', ', $columns) . ") VALUES ({$placeholders})";
        
        $params = [];
        foreach ($data as $key => $value) {
            $params[':' . $key] = $value;
        }
        
        $this->query($sql, $params);
        return $this->getConnection()->lastInsertId();
    }

    public function update($table, $data, $where, $whereParams = []) {
        $setParts = [];
        foreach (array_keys($data) as $column) {
            $setParts[] = "{$column} = :{$column}";
        }
        $setClause = implode(', ', $setParts);
        
        $sql = "UPDATE {$table} SET {$setClause} WHERE {$where}";
        
        $params = [];
        foreach ($data as $key => $value) {
            $params[':' . $key] = $value;
        }
        
        // 处理WHERE参数 - 确保参数名不冲突
        if (!empty($whereParams)) {
            if (is_array($whereParams)) {
                // 如果是位置参数数组，需要转换为命名参数
                if (array_keys($whereParams) === range(0, count($whereParams) - 1)) {
                    // 位置参数，转换为命名参数
                    $whereParamNames = [];
                    foreach ($whereParams as $index => $value) {
                        $paramName = ":where_param_" . $index;
                        $whereParamNames[] = $paramName;
                        $params[$paramName] = $value;
                    }
                    // 替换WHERE子句中的?为命名参数
                    $where = preg_replace('/\?/', array_shift($whereParamNames), $where, 1);
                } else {
                    // 已经是命名参数
                    $params = array_merge($params, $whereParams);
                }
            }
        }
        
        $finalSql = "UPDATE {$table} SET {$setClause} WHERE {$where}";
        
        // 记录SQL执行日志
        error_log("Executing SQL: " . $finalSql);
        error_log("Parameters: " . json_encode($params));
        
        $stmt = $this->query($finalSql, $params);
        return $stmt->rowCount(); // 返回受影响的行数
    }

    public function delete($table, $where, $params = []) {
        $sql = "DELETE FROM {$table} WHERE {$where}";
        return $this->query($sql, $params);
    }

    public function executeSchema($schemaFile) {
        if (!file_exists($schemaFile)) {
            throw new Exception("Schema文件不存在: " . $schemaFile);
        }
        
        $sql = file_get_contents($schemaFile);
        if ($sql === false) {
            throw new Exception("无法读取Schema文件: " . $schemaFile);
        }

        // 移除注释行和空行
        $lines = explode("\n", $sql);
        $cleanedLines = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if (!empty($line) && !preg_match('/^\s*--/', $line)) {
                $cleanedLines[] = $line;
            }
        }
        $cleanedSql = implode("\n", $cleanedLines);

        // 分割SQL语句 - 按分号分割，但保持多行语句完整
        $statements = [];
        $currentStatement = '';
        $lines = explode("\n", $cleanedSql);
        
        foreach ($lines as $line) {
            $currentStatement .= $line . "\n";
            if (substr(rtrim($line), -1) === ';') {
                $statement = trim($currentStatement);
                if (!empty($statement)) {
                    $statements[] = $statement;
                }
                $currentStatement = '';
            }
        }
        
        // 添加最后一个语句（如果没有以分号结尾）
        if (!empty(trim($currentStatement))) {
            $statements[] = trim($currentStatement);
        }

        $connection = $this->getConnection();
        $connection->beginTransaction();

        try {
            foreach ($statements as $index => $statement) {
                if (!empty(trim($statement))) {
                    try {
                        $connection->exec($statement);
                        error_log("执行SQL语句 " . ($index + 1) . " 成功");
                    } catch (PDOException $e) {
                        error_log("执行SQL语句失败 " . ($index + 1) . ": " . $statement);
                        throw new Exception("执行SQL语句失败 (语句 " . ($index + 1) . "): " . $e->getMessage() . "\n语句内容: " . substr($statement, 0, 200) . "...");
                    }
                }
            }
            $connection->commit();
            return true;
        } catch (Exception $e) {
            $connection->rollback();
            throw $e;
        }
    }
} 