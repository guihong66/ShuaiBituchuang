<?php

require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Config.php';
require_once __DIR__ . '/User.php';

class Image {
    private $db;
    private $config;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->config = new Config();
    }

    public function upload($file, $userId = null, $convertFormat = null) {
        try {
            // 验证文件
            $this->validateFile($file);

            // 生成文件名和路径
            $filename = $this->generateFilename($file['name'], $convertFormat);
            $uploadConfig = $this->config->getUploadConfig();
            $uploadPath = $uploadConfig['upload_path'];
            
            // 确保上传目录存在 - 保存到public目录下
            $fullUploadPath = __DIR__ . '/../../public/' . $uploadPath;
            if (!is_dir($fullUploadPath)) {
                mkdir($fullUploadPath, 0755, true);
            }

            // 按日期创建子目录
            $dateDir = date('Y/m/d');
            $targetDir = $fullUploadPath . $dateDir;
            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0755, true);
            }

            $targetPath = $targetDir . '/' . $filename;
            // URL路径不需要public前缀，因为Web服务器根目录就是public
            $relativePath = $uploadPath . $dateDir . '/' . $filename;

            // 移动和处理文件
            if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
                throw new Exception("文件上传失败");
            }

            // 格式转换
            if ($convertFormat && $convertFormat !== $this->getFileExtension($file['name'])) {
                $convertedPath = $this->convertImageFormat($targetPath, $convertFormat);
                if ($convertedPath) {
                    // 删除原文件
                    unlink($targetPath);
                    // 更新路径信息
                    $targetPath = $convertedPath;
                    $filename = basename($convertedPath);
                    $relativePath = $uploadPath . $dateDir . '/' . $filename;
                }
            }

            // 获取图片尺寸
            $imageInfo = getimagesize($targetPath);
            $width = $imageInfo ? $imageInfo[0] : null;
            $height = $imageInfo ? $imageInfo[1] : null;

            // 生成访问URL
            $baseUrl = $this->getBaseUrl();
            $url = $baseUrl . '/' . $relativePath;

            // 更新MIME类型
            $mimeType = $this->getMimeTypeFromExtension($this->getFileExtension($filename));

            // 保存到数据库
            $imageId = $this->db->insert('images', [
                'user_id' => $userId,
                'filename' => $filename,
                'original_name' => $file['name'],
                'mime_type' => $mimeType,
                'size' => filesize($targetPath),
                'path' => $relativePath,
                'url' => $url,
                'width' => $width,
                'height' => $height,
                'is_public' => 1
            ]);

            return [
                'id' => $imageId,
                'filename' => $filename,
                'original_name' => $file['name'],
                'url' => $url,
                'size' => filesize($targetPath),
                'width' => $width,
                'height' => $height,
                'converted_format' => $convertFormat
            ];
        } catch (Exception $e) {
            throw $e;
        }
    }

    // 格式转换功能
    public function convertImageFormat($sourcePath, $targetFormat) {
        try {
            $sourceInfo = getimagesize($sourcePath);
            if (!$sourceInfo) {
                return false;
            }

            $sourceExtension = strtolower(pathinfo($sourcePath, PATHINFO_EXTENSION));
            $targetFormat = strtolower($targetFormat);

            // 如果格式相同，不需要转换
            if ($sourceExtension === $targetFormat) {
                return $sourcePath;
            }

            // 创建源图像资源
            $sourceImage = null;
            switch ($sourceInfo[2]) {
                case IMAGETYPE_JPEG:
                    $sourceImage = imagecreatefromjpeg($sourcePath);
                    break;
                case IMAGETYPE_PNG:
                    $sourceImage = imagecreatefrompng($sourcePath);
                    // 保持PNG透明度
                    imagealphablending($sourceImage, false);
                    imagesavealpha($sourceImage, true);
                    break;
                case IMAGETYPE_GIF:
                    $sourceImage = imagecreatefromgif($sourcePath);
                    break;
                case IMAGETYPE_WEBP:
                    if (function_exists('imagecreatefromwebp')) {
                        $sourceImage = imagecreatefromwebp($sourcePath);
                    }
                    break;
                default:
                    return false;
            }

            if (!$sourceImage) {
                return false;
            }

            // 生成目标文件路径
            $pathInfo = pathinfo($sourcePath);
            $targetPath = $pathInfo['dirname'] . '/' . $pathInfo['filename'] . '.' . $targetFormat;

            // 保存为目标格式
            $success = false;
            switch ($targetFormat) {
                case 'jpg':
                case 'jpeg':
                    // 为JPEG创建白色背景（处理透明度）
                    $width = imagesx($sourceImage);
                    $height = imagesy($sourceImage);
                    $jpegImage = imagecreatetruecolor($width, $height);
                    $white = imagecolorallocate($jpegImage, 255, 255, 255);
                    imagefill($jpegImage, 0, 0, $white);
                    imagecopy($jpegImage, $sourceImage, 0, 0, 0, 0, $width, $height);
                    $success = imagejpeg($jpegImage, $targetPath, 90);
                    imagedestroy($jpegImage);
                    break;
                case 'png':
                    // 保持PNG透明度
                    imagesavealpha($sourceImage, true);
                    $success = imagepng($sourceImage, $targetPath, 9);
                    break;
                case 'webp':
                    if (function_exists('imagewebp')) {
                        $success = imagewebp($sourceImage, $targetPath, 90);
                    }
                    break;
            }

            imagedestroy($sourceImage);

            return $success ? $targetPath : false;
        } catch (Exception $e) {
            return false;
        }
    }

    // 生成不同格式的链接
    public function generateFormatLinks($imageId) {
        try {
            $image = $this->getImageById($imageId);
            if (!$image) {
                return [];
            }

            $formats = ['jpg', 'png', 'webp'];
            $links = [];
            $currentFormat = $this->getFileExtension($image['filename']);

            foreach ($formats as $format) {
                if ($format === $currentFormat) {
                    // 当前格式，直接使用原链接
                    $links[$format] = [
                        'url' => $image['url'],
                        'available' => true,
                        'current' => true
                    ];
                } else {
                    // 生成转换后的链接
                    $convertedFilename = pathinfo($image['filename'], PATHINFO_FILENAME) . '.' . $format;
                    $convertedPath = str_replace($image['filename'], $convertedFilename, $image['path']);
                    $convertedUrl = str_replace($image['filename'], $convertedFilename, $image['url']);
                    
                    // 检查转换后的文件是否存在，如果不存在则生成
                    $fullPath = __DIR__ . '/../../' . $convertedPath;
                    if (!file_exists($fullPath)) {
                        $originalPath = __DIR__ . '/../../' . $image['path'];
                        $this->convertImageFormat($originalPath, $format);
                    }

                    $links[$format] = [
                        'url' => $convertedUrl,
                        'available' => file_exists($fullPath),
                        'current' => false
                    ];
                }
            }

            return $links;
        } catch (Exception $e) {
            return [];
        }
    }

    public function getImageById($id) {
        try {
            $image = $this->db->fetchOne(
                "SELECT * FROM images WHERE id = ?",
                [$id]
            );
            return $image;
        } catch (Exception $e) {
            return null;
        }
    }

    public function getImagesByUser($userId, $page = 1, $limit = 20) {
        try {
            $offset = ($page - 1) * $limit;
            $images = $this->db->fetchAll(
                "SELECT * FROM images WHERE user_id = ? ORDER BY created_at DESC LIMIT {$limit} OFFSET {$offset}",
                [$userId]
            );

            $total = $this->db->fetchOne(
                "SELECT COUNT(*) as count FROM images WHERE user_id = ?",
                [$userId]
            )['count'];

            return [
                'images' => $images,
                'total' => $total,
                'pages' => ceil($total / $limit),
                'current_page' => $page
            ];
        } catch (Exception $e) {
            return ['images' => [], 'total' => 0, 'pages' => 0, 'current_page' => 1];
        }
    }

    public function getAllImages($page = 1, $limit = 20, $publicOnly = false) {
        try {
            $offset = ($page - 1) * $limit;
            $whereClause = $publicOnly ? "WHERE is_public = 1" : "";
            
            $images = $this->db->fetchAll(
                "SELECT i.*, u.username FROM images i 
                 LEFT JOIN users u ON i.user_id = u.id 
                 {$whereClause}
                 ORDER BY i.created_at DESC 
                 LIMIT {$limit} OFFSET {$offset}"
            );

            $countSql = "SELECT COUNT(*) as count FROM images" . ($publicOnly ? " WHERE is_public = 1" : "");
            $total = $this->db->fetchOne($countSql)['count'];

            return [
                'images' => $images,
                'total' => $total,
                'pages' => ceil($total / $limit),
                'current_page' => $page
            ];
        } catch (Exception $e) {
            return ['images' => [], 'total' => 0, 'pages' => 0, 'current_page' => 1];
        }
    }

    public function deleteImage($id, $userId = null) {
        try {
            // 获取图片信息
            $image = $this->getImageById($id);
            if (!$image) {
                throw new Exception("图片不存在");
            }

            // 权限检查：只有上传者或管理员可以删除
            if ($userId && $image['user_id'] && $image['user_id'] != $userId) {
                // 检查是否为管理员
                $user = new User();
                if (!$user->isAdmin($userId)) {
                    throw new Exception("没有权限删除此图片");
                }
            }

            // 删除物理文件和转换后的文件
            $filePath = __DIR__ . '/../../' . $image['path'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }

            // 删除可能的转换格式文件
            $formats = ['jpg', 'png', 'webp'];
            $currentFormat = $this->getFileExtension($image['filename']);
            foreach ($formats as $format) {
                if ($format !== $currentFormat) {
                    $convertedFilename = pathinfo($image['filename'], PATHINFO_FILENAME) . '.' . $format;
                    $convertedPath = str_replace($image['filename'], $convertedFilename, $image['path']);
                    $convertedFullPath = __DIR__ . '/../../' . $convertedPath;
                    if (file_exists($convertedFullPath)) {
                        unlink($convertedFullPath);
                    }
                }
            }

            // 删除数据库记录
            $this->db->delete('images', 'id = ?', [$id]);
            return true;
        } catch (Exception $e) {
            throw $e;
        }
    }

    public function incrementViews($id) {
        try {
            $this->db->query(
                "UPDATE images SET views = views + 1 WHERE id = ?",
                [$id]
            );
        } catch (Exception $e) {
            // 静默处理，不影响主要功能
        }
    }

    private function validateFile($file) {
        $uploadConfig = $this->config->getUploadConfig();

        // 检查上传错误
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception("文件上传出错");
        }

        // 检查文件大小
        if ($file['size'] > $uploadConfig['max_file_size']) {
            $maxSizeMB = round($uploadConfig['max_file_size'] / 1024 / 1024, 2);
            throw new Exception("文件大小超过限制（最大 {$maxSizeMB}MB）");
        }

        // 检查文件类型
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, $uploadConfig['allowed_extensions'])) {
            $allowedExt = implode(', ', $uploadConfig['allowed_extensions']);
            throw new Exception("不支持的文件类型，支持的格式：{$allowedExt}");
        }

        // 验证是否为真实图片
        $imageInfo = getimagesize($file['tmp_name']);
        if ($imageInfo === false) {
            throw new Exception("上传的文件不是有效的图片");
        }
    }

    private function generateFilename($originalName, $convertFormat = null) {
        $extension = $convertFormat ?: strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        $randomName = bin2hex(random_bytes(16));
        return $randomName . '.' . $extension;
    }

    private function getFileExtension($filename) {
        return strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    }

    private function getMimeTypeFromExtension($extension) {
        $mimeTypes = [
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'webp' => 'image/webp',
            'bmp' => 'image/bmp'
        ];
        return $mimeTypes[$extension] ?? 'image/jpeg';
    }

    private function getBaseUrl() {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $scriptName = dirname($_SERVER['SCRIPT_NAME']);
        $scriptName = $scriptName === '/' ? '' : $scriptName;
        return $protocol . '://' . $host . $scriptName;
    }
} 