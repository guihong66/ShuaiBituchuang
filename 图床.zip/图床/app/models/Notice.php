<?php

require_once __DIR__ . '/Database.php';

class Notice {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getByPosition($position) {
        try {
            $notice = $this->db->fetchOne(
                "SELECT * FROM notices WHERE position = ? AND is_active = 1",
                [$position]
            );
            return $notice;
        } catch (Exception $e) {
            return null;
        }
    }

    public function getAll() {
        try {
            $notices = $this->db->fetchAll(
                "SELECT * FROM notices ORDER BY position"
            );
            return $notices;
        } catch (Exception $e) {
            return [];
        }
    }

    public function update($position, $content, $isActive = 1) {
        try {
            // 检查是否已存在该位置的公告
            $existing = $this->db->fetchOne(
                "SELECT id FROM notices WHERE position = ?",
                [$position]
            );

            if ($existing) {
                // 更新现有公告
                $this->db->update(
                    'notices',
                    [
                        'content' => $content,
                        'is_active' => $isActive
                    ],
                    'position = ?',
                    [$position]
                );
            } else {
                // 插入新公告
                $this->db->insert('notices', [
                    'position' => $position,
                    'content' => $content,
                    'is_active' => $isActive
                ]);
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    public function setActive($position, $isActive) {
        try {
            $this->db->update(
                'notices',
                ['is_active' => $isActive],
                'position = ?',
                [$position]
            );
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    public function getHomeNotice() {
        return $this->getByPosition('home');
    }

    public function getLoginNotice() {
        return $this->getByPosition('login');
    }

    public function getRegisterNotice() {
        return $this->getByPosition('register');
    }
} 