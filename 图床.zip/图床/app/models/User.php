<?php

require_once __DIR__ . '/Database.php';

class User {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function register($username, $email, $password, $skipValidation = false) {
        try {
            // 安装模式时跳过重复检查
            if (!$skipValidation) {
                // 检查用户名和邮箱是否已存在
                if ($this->usernameExists($username)) {
                    throw new Exception("用户名已存在");
                }
                if ($this->emailExists($email)) {
                    throw new Exception("邮箱已被注册");
                }
            }

            // 密码加密
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // 插入用户数据
            $userId = $this->db->insert('users', [
                'username' => $username,
                'email' => $email,
                'password' => $hashedPassword,
                'role' => 'user',
                'status' => 1
            ]);

            return $userId;
        } catch (Exception $e) {
            throw $e;
        }
    }

    public function login($username, $password) {
        try {
            $user = $this->db->fetchOne(
                "SELECT * FROM users WHERE (username = ? OR email = ?) AND status = 1",
                [$username, $username]
            );

            if (!$user || !password_verify($password, $user['password'])) {
                throw new Exception("用户名或密码错误");
            }

            // 移除密码字段
            unset($user['password']);
            return $user;
        } catch (Exception $e) {
            throw $e;
        }
    }

    public function getUserById($id) {
        try {
            $user = $this->db->fetchOne(
                "SELECT id, username, email, avatar, role, status, created_at FROM users WHERE id = ?",
                [$id]
            );
            return $user;
        } catch (Exception $e) {
            return null;
        }
    }

    public function getUserByUsername($username) {
        try {
            $user = $this->db->fetchOne(
                "SELECT id, username, email, avatar, role, status, created_at FROM users WHERE username = ?",
                [$username]
            );
            return $user;
        } catch (Exception $e) {
            return null;
        }
    }

    public function updateProfile($userId, $data) {
        try {
            $allowedFields = ['username', 'email', 'avatar'];
            $updateData = [];

            foreach ($allowedFields as $field) {
                if (isset($data[$field])) {
                    $updateData[$field] = $data[$field];
                }
            }

            if (empty($updateData)) {
                return false;
            }

            // 检查用户名和邮箱唯一性
            if (isset($updateData['username']) && $this->usernameExists($updateData['username'], $userId)) {
                throw new Exception("用户名已存在");
            }
            if (isset($updateData['email']) && $this->emailExists($updateData['email'], $userId)) {
                throw new Exception("邮箱已被使用");
            }

            $this->db->update('users', $updateData, 'id = ?', [$userId]);
            return true;
        } catch (Exception $e) {
            throw $e;
        }
    }

    public function changePassword($userId, $oldPassword, $newPassword) {
        try {
            $user = $this->db->fetchOne(
                "SELECT password FROM users WHERE id = ?",
                [$userId]
            );

            if (!$user || !password_verify($oldPassword, $user['password'])) {
                throw new Exception("原密码错误");
            }

            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $this->db->update('users', ['password' => $hashedPassword], 'id = ?', [$userId]);
            return true;
        } catch (Exception $e) {
            throw $e;
        }
    }

    public function getAllUsers($page = 1, $limit = 20) {
        try {
            $offset = ($page - 1) * $limit;
            $users = $this->db->fetchAll(
                "SELECT id, username, email, role, status, created_at 
                 FROM users 
                 ORDER BY created_at DESC 
                 LIMIT {$limit} OFFSET {$offset}"
            );

            $total = $this->db->fetchOne("SELECT COUNT(*) as count FROM users")['count'];

            return [
                'users' => $users,
                'total' => $total,
                'pages' => ceil($total / $limit),
                'current_page' => $page
            ];
        } catch (Exception $e) {
            return ['users' => [], 'total' => 0, 'pages' => 0, 'current_page' => 1];
        }
    }

    public function updateUserStatus($userId, $status) {
        try {
            $this->db->update('users', ['status' => $status], 'id = ?', [$userId]);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    public function deleteUser($userId, $keepImages = true) {
        try {
            if (!$keepImages) {
                // 删除用户的所有图片记录
                $this->db->delete('images', 'user_id = ?', [$userId]);
            } else {
                // 将图片记录的用户ID设为NULL（匿名）
                $this->db->update('images', ['user_id' => null], 'user_id = ?', [$userId]);
            }

            $this->db->delete('users', 'id = ?', [$userId]);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    private function usernameExists($username, $excludeUserId = null) {
        $sql = "SELECT id FROM users WHERE username = ?";
        $params = [$username];

        if ($excludeUserId) {
            $sql .= " AND id != ?";
            $params[] = $excludeUserId;
        }

        $result = $this->db->fetchOne($sql, $params);
        return !empty($result);
    }

    private function emailExists($email, $excludeUserId = null) {
        $sql = "SELECT id FROM users WHERE email = ?";
        $params = [$email];

        if ($excludeUserId) {
            $sql .= " AND id != ?";
            $params[] = $excludeUserId;
        }

        $result = $this->db->fetchOne($sql, $params);
        return !empty($result);
    }

    public function isAdmin($userId) {
        $user = $this->getUserById($userId);
        return $user && $user['role'] === 'admin';
    }
} 