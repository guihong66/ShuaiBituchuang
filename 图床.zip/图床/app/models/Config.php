<?php

require_once __DIR__ . '/Database.php';

class Config {
    private $db;
    private static $cache = [];

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function get($name, $default = null) {
        // 先从缓存中获取
        if (isset(self::$cache[$name])) {
            return self::$cache[$name];
        }

        try {
            $result = $this->db->fetchOne(
                "SELECT value FROM configs WHERE name = ?",
                [$name]
            );
            
            $value = $result ? $result['value'] : $default;
            self::$cache[$name] = $value;
            return $value;
        } catch (Exception $e) {
            return $default;
        }
    }

    public function set($name, $value, $description = null) {
        try {
            // 检查配置是否存在
            $existing = $this->db->fetchOne(
                "SELECT id FROM configs WHERE name = ?",
                [$name]
            );

            if ($existing) {
                // 更新现有配置
                $result = $this->db->update(
                    'configs',
                    ['value' => $value],
                    'name = :config_name',
                    [':config_name' => $name]
                );
                if ($result === 0) {
                    error_log("配置更新影响行数为0: {$name}");
                }
                error_log("配置更新结果: {$name} = {$value}, 影响行数: {$result}");
            } else {
                // 插入新配置
                $result = $this->db->insert('configs', [
                    'name' => $name,
                    'value' => $value,
                    'description' => $description
                ]);
                if (!$result) {
                    throw new Exception("插入配置 {$name} 失败");
                }
            }

            // 更新缓存
            self::$cache[$name] = $value;
            
            // 记录日志
            error_log("Config set: {$name} = {$value}");
            
            return true;
        } catch (Exception $e) {
            error_log("Config set error: " . $e->getMessage());
            throw $e;
        }
    }

    public function getAll() {
        try {
            $configs = $this->db->fetchAll("SELECT name, value FROM configs");
            $result = [];
            foreach ($configs as $config) {
                $result[$config['name']] = $config['value'];
                self::$cache[$config['name']] = $config['value'];
            }
            return $result;
        } catch (Exception $e) {
            return [];
        }
    }

    public function getBool($name, $default = false) {
        $value = $this->get($name, $default ? '1' : '0');
        return in_array($value, ['1', 'true', 'yes', 'on'], true);
    }

    public function getInt($name, $default = 0) {
        return (int) $this->get($name, $default);
    }

    public function getArray($name, $default = [], $separator = ',') {
        $value = $this->get($name, '');
        if (empty($value)) {
            return $default;
        }
        return array_map('trim', explode($separator, $value));
    }

    // 获取网站基本信息
    public function getSiteInfo() {
        return [
            'name' => $this->get('site_name', '我的图床'),
            'title_suffix' => $this->get('title_suffix', ' - 免费图片存储'),
            'description' => $this->get('description', '简单、快速、稳定的图片存储服务'),
        ];
    }

    // 获取上传配置
    public function getUploadConfig() {
        return [
            'allow_guest_upload' => $this->getBool('allow_guest_upload', true),
            'max_file_size' => $this->getInt('max_file_size', 5242880), // 5MB
            'allowed_extensions' => $this->getArray('allowed_extensions', ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp']),
            'upload_path' => $this->get('upload_path', 'uploads/'),
        ];
    }

    // 清除缓存
    public static function clearCache() {
        self::$cache = [];
    }
} 