<?php

require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/Image.php';

class AdminController extends BaseController {
    private $image;
    private $db;

    public function __construct() {
        parent::__construct();
        $this->requireAdmin(); // 要求管理员权限
        $this->image = new Image();
        $this->db = Database::getInstance();
    }

    // 仪表板
    public function dashboard() {
        // 获取统计数据
        $stats = $this->getStatistics();
        
        $data = [
            'title' => '管理仪表板',
            'stats' => $stats,
            'recentImages' => $this->getRecentImages(10),
            'recentUsers' => $this->getRecentUsers(10)
        ];

        $this->render('admin/dashboard', $data);
    }

    // 用户管理
    public function users() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            return $this->handleUserAction();
        }

        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = $this->user->getAllUsers($page, 20);

        $data = [
            'title' => '用户管理',
            'users' => $result['users'],
            'pagination' => [
                'current' => $result['current_page'],
                'total' => $result['pages'],
                'prev' => $result['current_page'] > 1 ? $result['current_page'] - 1 : null,
                'next' => $result['current_page'] < $result['pages'] ? $result['current_page'] + 1 : null
            ],
            'csrfToken' => $this->generateCsrf()
        ];

        $this->render('admin/users', $data);
    }

    // 图片管理
    public function images() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            return $this->handleImageAction();
        }

        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = $this->image->getAllImages($page, 20, false);

        $data = [
            'title' => '图片管理',
            'images' => $result['images'],
            'pagination' => [
                'current' => $result['current_page'],
                'total' => $result['pages'],
                'prev' => $result['current_page'] > 1 ? $result['current_page'] - 1 : null,
                'next' => $result['current_page'] < $result['pages'] ? $result['current_page'] + 1 : null
            ],
            'csrfToken' => $this->generateCsrf()
        ];

        // 格式化图片数据
        foreach ($data['images'] as &$image) {
            $image['formatted_size'] = $this->formatFileSize($image['size']);
            $image['upload_time'] = $this->timeAgo($image['created_at']);
        }

        $this->render('admin/images', $data);
    }

    // 系统配置
    public function settings() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            return $this->handleSettingsUpdate();
        }

        $configs = $this->config->getAll();
        
        $data = [
            'title' => '系统设置',
            'configs' => $configs,
            'csrfToken' => $this->generateCsrf()
        ];

        $this->render('admin/settings', $data);
    }

    // 公告管理
    public function notices() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            return $this->handleNoticeUpdate();
        }

        $notices = $this->notice->getAll();
        
        $data = [
            'title' => '公告管理',
            'notices' => $notices,
            'csrfToken' => $this->generateCsrf()
        ];

        $this->render('admin/notices', $data);
    }

    // 处理用户操作
    private function handleUserAction() {
        try {
            if (!$this->validateCsrf()) {
                throw new Exception('CSRF验证失败');
            }

            $action = $_POST['action'] ?? '';
            $userId = (int)($_POST['user_id'] ?? 0);

            if ($userId <= 0) {
                throw new Exception('无效的用户ID');
            }

            switch ($action) {
                case 'edit':
                    $username = trim($_POST['username'] ?? '');
                    $email = trim($_POST['email'] ?? '');
                    $password = $_POST['password'] ?? '';
                    
                    if (empty($username) || empty($email)) {
                        throw new Exception('用户名和邮箱不能为空');
                    }
                    
                    $user = $this->user->getUserById($userId);
                    if (!$user) {
                        throw new Exception('用户不存在');
                    }
                    
                    if ($user['role'] === 'admin') {
                        throw new Exception('不能编辑管理员账号');
                    }
                    
                    $updateData = [
                        'username' => $username,
                        'email' => $email
                    ];
                    
                    if (!empty($password)) {
                        if (strlen($password) < 6) {
                            throw new Exception('密码长度不能少于6位');
                        }
                        $updateData['password'] = password_hash($password, PASSWORD_DEFAULT);
                    }
                    
                    $this->user->updateProfile($userId, $updateData);
                    $message = '用户信息已更新';
                    break;

                case 'toggle_status':
                    $user = $this->user->getUserById($userId);
                    if (!$user) {
                        throw new Exception('用户不存在');
                    }
                    
                    if ($user['role'] === 'admin') {
                        throw new Exception('不能操作管理员账号');
                    }
                    
                    $newStatus = $user['status'] == 1 ? 0 : 1;
                    $this->user->updateUserStatus($userId, $newStatus);
                    $message = $newStatus ? '用户已启用' : '用户已禁用';
                    break;

                case 'delete':
                    $user = $this->user->getUserById($userId);
                    if (!$user) {
                        throw new Exception('用户不存在');
                    }
                    
                    if ($user['role'] === 'admin') {
                        throw new Exception('不能删除管理员账号');
                    }
                    
                    $keepImages = isset($_POST['keep_images']);
                    $this->user->deleteUser($userId, $keepImages);
                    $message = '用户已删除';
                    break;

                default:
                    throw new Exception('无效的操作');
            }

            $this->json(['success' => true, 'message' => $message]);

        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 400);
        }
    }

    // 处理图片操作
    private function handleImageAction() {
        try {
            if (!$this->validateCsrf()) {
                throw new Exception('CSRF验证失败');
            }

            $action = $_POST['action'] ?? '';
            $imageId = (int)($_POST['image_id'] ?? 0);

            if ($imageId <= 0) {
                throw new Exception('无效的图片ID');
            }

            switch ($action) {
                case 'delete':
                    $this->image->deleteImage($imageId, $this->currentUser['id']);
                    $message = '图片已删除';
                    break;

                default:
                    throw new Exception('无效的操作');
            }

            $this->json(['success' => true, 'message' => $message]);

        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 400);
        }
    }

    // 处理系统设置更新
    private function handleSettingsUpdate() {
        try {
            if (!$this->validateCsrf()) {
                throw new Exception('CSRF验证失败');
            }

            $settings = [
                'site_name' => trim($_POST['site_name'] ?? ''),
                'title_suffix' => trim($_POST['title_suffix'] ?? ''),
                'description' => trim($_POST['description'] ?? ''),
                'allow_guest_upload' => ($_POST['allow_guest_upload'] ?? '0') === '1' ? '1' : '0',
                'allow_registration' => ($_POST['allow_registration'] ?? '0') === '1' ? '1' : '0',
                'gallery_enabled' => ($_POST['gallery_enabled'] ?? '0') === '1' ? '1' : '0',
                'typewriter_enabled' => ($_POST['typewriter_enabled'] ?? '0') === '1' ? '1' : '0',
                'typewriter_speed' => (string)((int)($_POST['typewriter_speed'] ?? 100)),
                'sakura_enabled' => ($_POST['sakura_enabled'] ?? '0') === '1' ? '1' : '0',
                'background_image' => trim($_POST['background_image'] ?? ''),
                'max_file_size' => (string)((int)($_POST['max_file_size'] ?? 5242880)),
                'allowed_extensions' => trim($_POST['allowed_extensions'] ?? '')
            ];

            // 保存每个设置并记录结果
            $savedSettings = [];
            foreach ($settings as $key => $value) {
                try {
                    $result = $this->config->set($key, $value);
                    $savedSettings[$key] = $value;
                    error_log("保存设置成功: {$key} = {$value}");
                } catch (Exception $e) {
                    error_log("保存设置失败: {$key} - " . $e->getMessage());
                    throw new Exception("保存设置 {$key} 失败: " . $e->getMessage());
                }
            }

            // 清除配置缓存
            $this->config->clearCache();
            
            // 验证保存结果
            foreach ($savedSettings as $key => $expectedValue) {
                $actualValue = $this->config->get($key);
                
                // 对于数字类型的配置，转换为字符串比较
                if (in_array($key, ['max_file_size', 'typewriter_speed'])) {
                    $actualValue = (string)$actualValue;
                    $expectedValue = (string)$expectedValue;
                }
                
                if ($actualValue !== $expectedValue) {
                    error_log("设置验证失败: {$key} 期望值 '{$expectedValue}' (类型:" . gettype($expectedValue) . "), 实际值 '{$actualValue}' (类型:" . gettype($actualValue) . ")");
                    throw new Exception("设置保存验证失败: {$key}");
                } else {
                    error_log("设置验证成功: {$key} = '{$actualValue}'");
                }
            }

            $this->json(['success' => true, 'message' => '设置已保存']);

        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 400);
        }
    }

    // 处理公告更新
    private function handleNoticeUpdate() {
        try {
            if (!$this->validateCsrf()) {
                throw new Exception('CSRF验证失败');
            }

            $notices = [
                'home' => [
                    'content' => $_POST['home_notice'] ?? '',
                    'is_active' => isset($_POST['home_notice_active']) ? 1 : 0
                ],
                'login' => [
                    'content' => $_POST['login_notice'] ?? '',
                    'is_active' => isset($_POST['login_notice_active']) ? 1 : 0
                ],
                'register' => [
                    'content' => $_POST['register_notice'] ?? '',
                    'is_active' => isset($_POST['register_notice_active']) ? 1 : 0
                ]
            ];

            foreach ($notices as $position => $notice) {
                $this->notice->update($position, $notice['content'], $notice['is_active']);
            }

            $this->json(['success' => true, 'message' => '公告已更新']);

        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 400);
        }
    }

    // 获取统计数据
    private function getStatistics() {
        try {
            $totalUsers = $this->db->fetchOne("SELECT COUNT(*) as count FROM users")['count'];
            $totalImages = $this->db->fetchOne("SELECT COUNT(*) as count FROM images")['count'];
            $totalViews = $this->db->fetchOne("SELECT SUM(views) as total FROM images")['total'] ?? 0;
            
            // 今日数据
            $today = date('Y-m-d');
            $todayUsers = $this->db->fetchOne(
                "SELECT COUNT(*) as count FROM users WHERE DATE(created_at) = ?", 
                [$today]
            )['count'];
            $todayImages = $this->db->fetchOne(
                "SELECT COUNT(*) as count FROM images WHERE DATE(created_at) = ?", 
                [$today]
            )['count'];

            // 存储使用情况
            $storageUsed = $this->db->fetchOne("SELECT SUM(size) as total FROM images")['total'] ?? 0;

            return [
                'total_users' => $totalUsers,
                'total_images' => $totalImages,
                'total_views' => $totalViews,
                'today_users' => $todayUsers,
                'today_images' => $todayImages,
                'storage_used' => $this->formatFileSize($storageUsed)
            ];
        } catch (Exception $e) {
            return [
                'total_users' => 0,
                'total_images' => 0,
                'total_views' => 0,
                'today_users' => 0,
                'today_images' => 0,
                'storage_used' => '0 B'
            ];
        }
    }

    // 获取最近图片
    private function getRecentImages($limit = 10) {
        try {
            return $this->db->fetchAll(
                "SELECT i.*, u.username FROM images i 
                 LEFT JOIN users u ON i.user_id = u.id 
                 ORDER BY i.created_at DESC 
                 LIMIT {$limit}"
            );
        } catch (Exception $e) {
            return [];
        }
    }

    // 获取最近用户
    private function getRecentUsers($limit = 10) {
        try {
            return $this->db->fetchAll(
                "SELECT id, username, email, created_at FROM users 
                 ORDER BY created_at DESC 
                 LIMIT {$limit}"
            );
        } catch (Exception $e) {
            return [];
        }
    }
} 