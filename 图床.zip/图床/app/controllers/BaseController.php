<?php

require_once __DIR__ . '/../models/Config.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Notice.php';

class BaseController {
    protected $config;
    protected $user;
    protected $notice;
    protected $currentUser = null;

    public function __construct() {
        $this->config = new Config();
        $this->user = new User();
        $this->notice = new Notice();
        
        // 检查用户登录状态
        $this->checkAuth();
    }

    protected function checkAuth() {
        session_start();
        if (isset($_SESSION['user_id'])) {
            $this->currentUser = $this->user->getUserById($_SESSION['user_id']);
            if (!$this->currentUser || $this->currentUser['status'] != 1) {
                $this->logout();
            }
        }
    }

    protected function requireAuth() {
        if (!$this->currentUser) {
            $this->redirect('/login.php');
        }
    }

    protected function requireAdmin() {
        $this->requireAuth();
        if ($this->currentUser['role'] !== 'admin') {
            $this->error403();
        }
    }

    protected function login($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $this->currentUser = $user;
    }

    protected function logout() {
        session_destroy();
        $this->currentUser = null;
    }

    protected function redirect($url) {
        header('Location: ' . $url);
        exit;
    }

    protected function json($data, $code = 200) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    protected function error404() {
        http_response_code(404);
        $this->render('errors/404', ['title' => '页面未找到']);
    }

    protected function error403() {
        http_response_code(403);
        $this->render('errors/403', ['title' => '访问被拒绝']);
    }

    protected function error500($message = '服务器内部错误') {
        http_response_code(500);
        $this->render('errors/500', ['title' => '服务器错误', 'message' => $message]);
    }

    protected function render($view, $data = []) {
        // 获取全局数据
        $siteInfo = $this->config->getSiteInfo();
        $globalData = [
            'siteInfo' => [
                'name' => $siteInfo['site_name'],
                'title_suffix' => $siteInfo['title_suffix'], // 保留标题后缀
                'description' => '', // 不在页脚显示描述
            ],
            'currentUser' => $this->currentUser,
            'uploadConfig' => $this->config->getUploadConfig(),
            'config' => $this->config, // 添加config对象供视图使用
        ];

        // 合并数据
        $data = array_merge($globalData, $data);

        // 提取变量到当前作用域
        extract($data);

        // 包含视图文件
        $viewFile = __DIR__ . '/../views/' . $view . '.php';
        if (file_exists($viewFile)) {
            include $viewFile;
        } else {
            throw new Exception("视图文件不存在: {$view}");
        }
        exit;
    }

    protected function getNotice($position) {
        return $this->notice->getByPosition($position);
    }

    protected function validateCsrf() {
        if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token'])) {
            return false;
        }
        return hash_equals($_SESSION['csrf_token'], $_POST['csrf_token']);
    }

    protected function generateCsrf() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    protected function formatFileSize($bytes) {
        $units = ['B', 'KB', 'MB', 'GB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        $bytes /= (1 << (10 * $pow));
        return round($bytes, 2) . ' ' . $units[$pow];
    }

    protected function timeAgo($datetime) {
        $time = time() - strtotime($datetime);
        
        if ($time < 60) return '刚刚';
        if ($time < 3600) return floor($time/60) . '分钟前';
        if ($time < 86400) return floor($time/3600) . '小时前';
        if ($time < 2592000) return floor($time/86400) . '天前';
        if ($time < 31536000) return floor($time/2592000) . '个月前';
        return floor($time/31536000) . '年前';
    }
} 