<?php

require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/Image.php';

class AuthController extends BaseController {
    private $image;

    public function __construct() {
        parent::__construct();
        $this->image = new Image();
    }

    public function showLogin() {
        if ($this->currentUser) {
            $this->redirect('/index.php');
        }

        $loginNotice = $this->getNotice('login');
        
        $data = [
            'title' => '用户登录',
            'loginNotice' => $loginNotice,
            'csrfToken' => $this->generateCsrf()
        ];

        $this->render('auth/login', $data);
    }

    public function doLogin() {
        try {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('请求方法不正确');
            }

            if (!$this->validateCsrf()) {
                throw new Exception('CSRF验证失败');
            }

            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            $remember = isset($_POST['remember']);

            if (empty($username) || empty($password)) {
                throw new Exception('请输入用户名和密码');
            }

            $user = $this->user->login($username, $password);
            $this->login($user);

            // 记住我功能
            if ($remember) {
                $token = bin2hex(random_bytes(32));
                setcookie('remember_token', $token, time() + 30 * 24 * 3600, '/');
                // 这里可以将token保存到数据库，实现真正的记住我功能
            }

            $this->json(['success' => true, 'message' => '登录成功']);

        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 400);
        }
    }

    public function showRegister() {
        if ($this->currentUser) {
            $this->redirect('/index.php');
        }

        // 检查是否允许注册
        if (!$this->config->getBool('allow_registration', true)) {
            $this->error403();
        }

        $registerNotice = $this->getNotice('register');
        
        $data = [
            'title' => '用户注册',
            'registerNotice' => $registerNotice,
            'csrfToken' => $this->generateCsrf()
        ];

        $this->render('auth/register', $data);
    }

    public function register() {
        try {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('请求方法不正确');
            }

            if (!$this->validateCsrf()) {
                throw new Exception('CSRF验证失败');
            }

            // 检查是否允许注册
            if (!$this->config->getBool('allow_registration', true)) {
                throw new Exception('当前不允许注册新用户');
            }

            $username = trim($_POST['username'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $passwordConfirm = $_POST['password_confirm'] ?? '';

            if (empty($username) || empty($email) || empty($password)) {
                throw new Exception('请填写完整信息');
            }

            if ($password !== $passwordConfirm) {
                throw new Exception('两次输入的密码不一致');
            }

            if (strlen($password) < 6) {
                throw new Exception('密码长度不能少于6位');
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception('邮箱格式不正确');
            }

            $userId = $this->user->register($username, $email, $password);
            $user = $this->user->getUserById($userId);
            $this->login($user);

            $this->json(['success' => true, 'message' => '注册成功']);

        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 400);
        }
    }

    public function logout() {
        // 调用父类的logout方法
        parent::logout();
        
        // 清除记住我cookie
        if (isset($_COOKIE['remember_token'])) {
            setcookie('remember_token', '', time() - 3600, '/');
        }
        
        $this->redirect('/index.php');
    }

    public function profile() {
        $this->requireAuth();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                if (!$this->validateCsrf()) {
                    throw new Exception('CSRF验证失败');
                }

                $updateData = [];
                if (isset($_POST['username'])) {
                    $updateData['username'] = trim($_POST['username']);
                }
                if (isset($_POST['email'])) {
                    $updateData['email'] = trim($_POST['email']);
                    if (!filter_var($updateData['email'], FILTER_VALIDATE_EMAIL)) {
                        throw new Exception('邮箱格式不正确');
                    }
                }

                if (!empty($updateData)) {
                    $this->user->updateProfile($this->currentUser['id'], $updateData);
                    $this->currentUser = $this->user->getUserById($this->currentUser['id']);
                }

                $this->json(['success' => true, 'message' => '资料更新成功']);

            } catch (Exception $e) {
                $this->json(['success' => false, 'message' => $e->getMessage()], 400);
            }
        }

        // 获取用户的图片
        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = $this->image->getImagesByUser($this->currentUser['id'], $page, 12);

        $data = [
            'title' => '个人中心',
            'user' => $this->currentUser,
            'images' => $result['images'],
            'pagination' => [
                'current' => $result['current_page'],
                'total' => $result['pages'],
                'prev' => $result['current_page'] > 1 ? $result['current_page'] - 1 : null,
                'next' => $result['current_page'] < $result['pages'] ? $result['current_page'] + 1 : null
            ],
            'csrfToken' => $this->generateCsrf()
        ];

        // 格式化图片数据
        foreach ($data['images'] as &$image) {
            $image['formatted_size'] = $this->formatFileSize($image['size']);
            $image['upload_time'] = $this->timeAgo($image['created_at']);
        }

        $this->render('auth/profile', $data);
    }

    public function changePassword() {
        $this->requireAuth();

        try {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('请求方法不正确');
            }

            if (!$this->validateCsrf()) {
                throw new Exception('CSRF验证失败');
            }

            $oldPassword = $_POST['old_password'] ?? '';
            $newPassword = $_POST['new_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';

            if (empty($oldPassword) || empty($newPassword)) {
                throw new Exception('请填写完整信息');
            }

            if ($newPassword !== $confirmPassword) {
                throw new Exception('两次输入的新密码不一致');
            }

            if (strlen($newPassword) < 6) {
                throw new Exception('新密码长度不能少于6位');
            }

            $this->user->changePassword($this->currentUser['id'], $oldPassword, $newPassword);

            $this->json(['success' => true, 'message' => '密码修改成功']);

        } catch (Exception $e) {
            $this->json(['success' => false, 'message' => $e->getMessage()], 400);
        }
    }
} 