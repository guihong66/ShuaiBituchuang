<?php

require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/Image.php';
require_once __DIR__ . '/../models/User.php';

class HomeController extends BaseController {
    private $image;

    public function __construct() {
        parent::__construct();
        $this->image = new Image();
    }

    public function index() {
        $uploadConfig = $this->config->getUploadConfig();
        $homeNotice = $this->getNotice('home');
        
        $data = [
            'title' => $this->config->get('site_name', '我的图床'),
            'description' => $this->config->get('description', '简单、快速、稳定的图片存储服务'),
            'homeNotice' => $homeNotice,
            'allowGuestUpload' => $uploadConfig['allow_guest_upload'],
            'gallery_enabled' => $this->config->getBool('gallery_enabled', true),
            'maxFileSize' => $this->formatFileSize($uploadConfig['max_file_size']),
            'allowedExtensions' => implode(', ', $uploadConfig['allowed_extensions']),
            'csrfToken' => $this->generateCsrf()
        ];

        $this->render('home/index', $data);
    }

    public function upload() {
        try {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('请求方法不正确');
            }

            if (!$this->validateCsrf()) {
                throw new Exception('CSRF验证失败');
            }

            // 检查上传权限
            $uploadConfig = $this->config->getUploadConfig();
            if (!$uploadConfig['allow_guest_upload'] && !$this->currentUser) {
                throw new Exception('请先登录后再上传图片');
            }

            if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
                throw new Exception('没有选择文件或上传失败');
            }

            $userId = $this->currentUser ? $this->currentUser['id'] : null;
            $convertFormat = $_POST['convert_format'] ?? null;
            $result = $this->image->upload($_FILES['image'], $userId, $convertFormat);

            $this->json([
                'success' => true,
                'message' => '上传成功',
                'data' => $result
            ]);

        } catch (Exception $e) {
            $this->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }

    public function view() {
        $id = $_GET['id'] ?? '';
        if (empty($id) || !is_numeric($id)) {
            $this->error404();
        }

        $image = $this->image->getImageById($id);
        if (!$image) {
            $this->error404();
        }

        // 增加浏览次数
        $this->image->incrementViews($id);

        // 获取上传者信息
        $uploader = null;
        if ($image['user_id']) {
            $uploader = $this->user->getUserById($image['user_id']);
        }

        // 生成不同格式的链接
        $formatLinks = $this->image->generateFormatLinks($id);

        $data = [
            'title' => '查看图片 - ' . $image['original_name'],
            'image' => $image,
            'uploader' => $uploader,
            'formattedSize' => $this->formatFileSize($image['size']),
            'uploadTime' => $this->timeAgo($image['created_at']),
            'formatLinks' => $formatLinks
        ];

        $this->render('home/view', $data);
    }

    public function gallery() {
        // 检查画廊是否启用
        $galleryEnabled = $this->config->get('gallery_enabled', '1');
        if ($galleryEnabled != '1') {
            $data = [
                'title' => '画廊已关闭',
                'message' => '画廊功能已被管理员关闭'
            ];
            $this->render('home/gallery_disabled', $data);
            return;
        }

        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = $this->image->getAllImages($page, 12, true);

        $data = [
            'title' => '图片画廊',
            'images' => $result['images'],
            'pagination' => [
                'current' => $result['current_page'],
                'total' => $result['pages'],
                'prev' => $result['current_page'] > 1 ? $result['current_page'] - 1 : null,
                'next' => $result['current_page'] < $result['pages'] ? $result['current_page'] + 1 : null
            ]
        ];

        // 格式化图片数据
        foreach ($data['images'] as &$image) {
            $image['formatted_size'] = $this->formatFileSize($image['size']);
            $image['upload_time'] = $this->timeAgo($image['created_at']);
        }

        $this->render('home/gallery', $data);
    }

    // 图片格式转换
    public function convert() {
        try {
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('请求方法不正确');
            }

            if (!$this->validateCsrf()) {
                throw new Exception('CSRF验证失败');
            }

            $imageId = (int)($_POST['image_id'] ?? 0);
            $targetFormat = $_POST['target_format'] ?? '';

            if ($imageId <= 0) {
                throw new Exception('无效的图片ID');
            }

            if (!in_array($targetFormat, ['jpg', 'png', 'webp'])) {
                throw new Exception('不支持的转换格式');
            }

            $image = $this->image->getImageById($imageId);
            if (!$image) {
                throw new Exception('图片不存在');
            }

            // 权限检查：只有上传者或管理员可以转换
            if ($this->currentUser && $image['user_id'] && $image['user_id'] != $this->currentUser['id']) {
                $user = new User();
                if (!$user->isAdmin($this->currentUser['id'])) {
                    throw new Exception('没有权限转换此图片');
                }
            }

            // 生成转换后的链接
            $formatLinks = $this->image->generateFormatLinks($imageId);
            
            if (isset($formatLinks[$targetFormat]) && $formatLinks[$targetFormat]['available']) {
                $this->json([
                    'success' => true,
                    'message' => '格式转换成功',
                    'url' => $formatLinks[$targetFormat]['url'],
                    'format' => strtoupper($targetFormat)
                ]);
            } else {
                throw new Exception('格式转换失败');
            }

        } catch (Exception $e) {
            $this->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 400);
        }
    }
} 