<?php

// 检查是否已安装
if (!file_exists(__DIR__ . '/install.lock')) {
    header('Location: install.php');
    exit;
}

// 自动加载
require_once __DIR__ . '/../app/controllers/HomeController.php';

try {
    $controller = new HomeController();
    
    // 简单路由
    $action = $_GET['action'] ?? 'index';
    
    switch ($action) {
        case 'index':
        default:
            $controller->index();
            break;
        case 'upload':
            $controller->upload();
            break;
        case 'view':
            $controller->view();
            break;
        case 'gallery':
            $controller->gallery();
            break;
        case 'convert':
            $controller->convert();
            break;
    }
} catch (Exception $e) {
    error_log($e->getMessage());
    http_response_code(500);
    echo "系统错误，请稍后再试";
} 