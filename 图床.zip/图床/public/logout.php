<?php

// 检查是否已安装
if (!file_exists(__DIR__ . '/install.lock')) {
    header('Location: install.php');
    exit;
}

require_once __DIR__ . '/../app/controllers/AuthController.php';

try {
    $controller = new AuthController();
    $controller->logout();
} catch (Exception $e) {
    error_log($e->getMessage());
    header('Location: index.php');
} 