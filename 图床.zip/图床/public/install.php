<?php
session_start();

// 检查是否已安装
if (file_exists(__DIR__ . '/install.lock')) {
    header('Location: index.php');
    exit;
}

require_once __DIR__ . '/../app/models/Database.php';
require_once __DIR__ . '/../app/models/User.php';

$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$error = '';
$success = '';

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step === 1) {
        // 数据库连接测试
        $host = trim($_POST['host'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $database = trim($_POST['database'] ?? '');

        if (empty($host) || empty($username) || empty($database)) {
            $error = '请填写完整的数据库信息';
        } else {
            try {
                $db = Database::getInstance();
                $db->connect($host, $username, $password, $database);
                
                // 保存数据库配置到会话
                $_SESSION['db_config'] = [
                    'host' => $host,
                    'username' => $username,
                    'password' => $password,
                    'database' => $database
                ];
                
                header('Location: install.php?step=2');
                exit;
            } catch (Exception $e) {
                $error = '数据库连接失败: ' . $e->getMessage();
            }
        }
    } elseif ($step === 2) {
        // 管理员账号创建
        $adminUsername = trim($_POST['admin_username'] ?? '');
        $adminEmail = trim($_POST['admin_email'] ?? '');
        $adminPassword = $_POST['admin_password'] ?? '';
        $adminPasswordConfirm = $_POST['admin_password_confirm'] ?? '';

        if (empty($adminUsername) || empty($adminEmail) || empty($adminPassword)) {
            $error = '请填写完整的管理员信息';
        } elseif ($adminPassword !== $adminPasswordConfirm) {
            $error = '两次输入的密码不一致';
        } elseif (strlen($adminPassword) < 6) {
            $error = '密码长度不能少于6位';
        } else {
            $_SESSION['admin_config'] = [
                'username' => $adminUsername,
                'email' => $adminEmail,
                'password' => $adminPassword
            ];
            
            header('Location: install.php?step=3');
            exit;
        }
    } elseif ($step === 3) {
        // 执行安装
        try {
            if (!isset($_SESSION['db_config']) || !isset($_SESSION['admin_config'])) {
                throw new Exception('安装信息不完整，请重新开始');
            }

            $dbConfig = $_SESSION['db_config'];
            $adminConfig = $_SESSION['admin_config'];

            // 连接数据库
            $db = Database::getInstance();
            $db->connect($dbConfig['host'], $dbConfig['username'], $dbConfig['password'], $dbConfig['database']);

            try {
                // 执行数据库迁移
                $schemaFile = __DIR__ . '/../database/schema.sql';
                if (!file_exists($schemaFile)) {
                    throw new Exception("数据库Schema文件不存在: " . $schemaFile);
                }
                
                $db->executeSchema($schemaFile);
                
                // 验证表是否创建成功
                $tables = ['users', 'images', 'configs', 'notices'];
                foreach ($tables as $table) {
                    $result = $db->fetchOne("SHOW TABLES LIKE '" . $table . "'");
                    if (!$result) {
                        throw new Exception("数据表 '{$table}' 创建失败");
                    }
                }
                
                // 创建管理员账号 - 检查是否已存在
                $user = new User();
                $existingAdmin = $db->fetchOne("SELECT id FROM users WHERE username = :username OR email = :email", [
                    ':username' => $adminConfig['username'],
                    ':email' => $adminConfig['email']
                ]);
                
                if ($existingAdmin) {
                    // 如果管理员已存在，更新为管理员角色
                    $adminId = $existingAdmin['id'];
                    $db->update('users', ['role' => 'admin'], 'id = :user_id', [':user_id' => $adminId]);
                } else {
                    // 创建新的管理员账号
                    $adminId = $user->register($adminConfig['username'], $adminConfig['email'], $adminConfig['password'], true);
                    
                    // 设置为管理员
                    $db->update('users', ['role' => 'admin'], 'id = :user_id', [':user_id' => $adminId]);
                }

                // 保存数据库配置文件
                $configContent = "<?php\nreturn " . var_export($dbConfig, true) . ";\n";
                $configDir = __DIR__ . '/../config';
                if (!is_dir($configDir)) {
                    mkdir($configDir, 0755, true);
                }
                file_put_contents($configDir . '/database.php', $configContent);

                // 创建安装锁定文件
                file_put_contents(__DIR__ . '/install.lock', date('Y-m-d H:i:s'));

                // 清理会话
                unset($_SESSION['db_config'], $_SESSION['admin_config']);

                $success = '安装完成！';
                $step = 4;
                
            } catch (Exception $e) {
                $error = '安装失败: ' . $e->getMessage();
                error_log("安装错误: " . $e->getMessage());
                $step = 3;
            }
        } catch (Exception $e) {
            $error = '安装失败: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>图床系统安装</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .install-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
        }
        .step-indicator {
            display: flex;
            justify-content: center;
            margin-bottom: 2rem;
        }
        .step {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 10px;
            font-weight: bold;
            color: white;
        }
        .step.active {
            background: #667eea;
        }
        .step.completed {
            background: #28a745;
        }
        .step.pending {
            background: #6c757d;
        }
        .step-line {
            width: 60px;
            height: 2px;
            background: #dee2e6;
            margin-top: 19px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="install-card p-5">
                    <div class="text-center mb-4">
                        <h2 class="fw-bold">图床系统安装</h2>
                        <p class="text-muted">欢迎使用图床系统，请按照步骤完成安装</p>
                    </div>

                    <!-- 步骤指示器 -->
                    <div class="step-indicator">
                        <div class="step <?= $step >= 1 ? ($step > 1 ? 'completed' : 'active') : 'pending' ?>">1</div>
                        <div class="step-line"></div>
                        <div class="step <?= $step >= 2 ? ($step > 2 ? 'completed' : 'active') : 'pending' ?>">2</div>
                        <div class="step-line"></div>
                        <div class="step <?= $step >= 3 ? ($step > 3 ? 'completed' : 'active') : 'pending' ?>">3</div>
                        <div class="step-line"></div>
                        <div class="step <?= $step >= 4 ? 'completed' : 'pending' ?>">4</div>
                    </div>

                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
                    <?php endif; ?>

                    <?php if ($step === 1): ?>
                        <!-- 步骤1: 数据库配置 -->
                        <h4>步骤1: 数据库配置</h4>
                        <p class="text-muted mb-4">请输入您的MySQL数据库连接信息</p>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">数据库主机</label>
                                <input type="text" name="host" class="form-control" value="<?= htmlspecialchars($_POST['host'] ?? 'localhost') ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">数据库用户名</label>
                                <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">数据库密码</label>
                                <input type="password" name="password" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">数据库名称</label>
                                <input type="text" name="database" class="form-control" value="<?= htmlspecialchars($_POST['database'] ?? '') ?>" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">测试连接并继续</button>
                        </form>

                    <?php elseif ($step === 2): ?>
                        <!-- 步骤2: 管理员账号 -->
                        <h4>步骤2: 创建管理员账号</h4>
                        <p class="text-muted mb-4">请设置系统管理员账号</p>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">管理员用户名</label>
                                <input type="text" name="admin_username" class="form-control" value="<?= htmlspecialchars($_POST['admin_username'] ?? '') ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">管理员邮箱</label>
                                <input type="email" name="admin_email" class="form-control" value="<?= htmlspecialchars($_POST['admin_email'] ?? '') ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">管理员密码</label>
                                <input type="password" name="admin_password" class="form-control" minlength="6" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">确认密码</label>
                                <input type="password" name="admin_password_confirm" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">创建管理员并继续</button>
                        </form>

                    <?php elseif ($step === 3): ?>
                        <!-- 步骤3: 确认安装 -->
                        <h4>步骤3: 确认安装</h4>
                        <p class="text-muted mb-4">请确认以下信息，点击安装按钮开始安装</p>
                        
                        <div class="card mb-3">
                            <div class="card-body">
                                <h6>数据库信息</h6>
                                <p class="mb-1">主机: <?= htmlspecialchars($_SESSION['db_config']['host'] ?? '') ?></p>
                                <p class="mb-1">数据库: <?= htmlspecialchars($_SESSION['db_config']['database'] ?? '') ?></p>
                                <p class="mb-0">用户名: <?= htmlspecialchars($_SESSION['db_config']['username'] ?? '') ?></p>
                            </div>
                        </div>
                        
                        <div class="card mb-4">
                            <div class="card-body">
                                <h6>管理员信息</h6>
                                <p class="mb-1">用户名: <?= htmlspecialchars($_SESSION['admin_config']['username'] ?? '') ?></p>
                                <p class="mb-0">邮箱: <?= htmlspecialchars($_SESSION['admin_config']['email'] ?? '') ?></p>
                            </div>
                        </div>
                        
                        <form method="POST">
                            <button type="submit" class="btn btn-success w-100">开始安装</button>
                        </form>
                        
                        <div class="text-center mt-3">
                            <a href="install.php?step=1" class="btn btn-outline-secondary">返回修改</a>
                        </div>

                    <?php elseif ($step === 4): ?>
                        <!-- 步骤4: 安装完成 -->
                        <div class="text-center">
                            <div class="mb-4">
                                <i class="fas fa-check-circle text-success" style="font-size: 4rem;"></i>
                            </div>
                            <h4>安装完成！</h4>
                            <p class="text-muted mb-4">图床系统已成功安装，您现在可以开始使用了</p>
                            
                            <div class="d-grid gap-2">
                                <a href="index.php" class="btn btn-primary">访问首页</a>
                                <a href="admin/" class="btn btn-outline-secondary">进入管理后台</a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>