<?php

// 检查是否已安装
if (!file_exists(__DIR__ . '/install.lock')) {
    header('Location: install.php');
    exit;
}

require_once __DIR__ . '/../app/controllers/AuthController.php';

try {
    $controller = new AuthController();
    
    $action = $_GET['action'] ?? 'profile';
    
    switch ($action) {
        case 'profile':
        default:
            $controller->profile();
            break;
        case 'change_password':
            $controller->changePassword();
            break;
    }
} catch (Exception $e) {
    error_log($e->getMessage());
    http_response_code(500);
    echo "系统错误，请稍后再试";
} 