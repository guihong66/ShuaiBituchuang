-- 图床系统数据库结构
-- 创建时间: 2025-01-20

-- 1. 用户表
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL UNIQUE,
  `email` varchar(100) NOT NULL UNIQUE,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1: active, 0: inactive',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. 图片表
CREATE TABLE IF NOT EXISTS `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT '关联用户ID，NULL表示游客上传',
  `filename` varchar(255) NOT NULL COMMENT '存储的文件名',
  `original_name` varchar(255) NOT NULL COMMENT '原始文件名',
  `mime_type` varchar(50) NOT NULL COMMENT '文件类型',
  `size` int(11) NOT NULL COMMENT '文件大小(字节)',
  `path` varchar(255) NOT NULL COMMENT '存储路径',
  `url` varchar(255) NOT NULL COMMENT '访问URL',
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 1,
  `views` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `is_public` (`is_public`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `images_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. 系统配置表
CREATE TABLE IF NOT EXISTS `configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL UNIQUE COMMENT '配置项名称',
  `value` text COMMENT '配置项值',
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. 公告表
CREATE TABLE IF NOT EXISTS `notices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` enum('home','login','register') NOT NULL COMMENT '公告位置',
  `content` text NOT NULL COMMENT '公告内容，支持HTML',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `position` (`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 初始化默认配置数据
INSERT IGNORE INTO `configs` (`name`, `value`, `description`) VALUES
('site_name', '我的图床', '图床网站名称'),
('title_suffix', ' - 免费图片存储', '网站标题后缀'),
('description', '简单、快速、稳定的图片存储服务', '网站描述'),
('allow_guest_upload', '1', '是否允许游客上传(1/0)'),
('allow_registration', '1', '是否允许用户注册(1/0)'),
('gallery_enabled', '1', '是否启用画廊功能(1/0)'),
('typewriter_enabled', '1', '是否启用打字机效果(1/0)'),
('typewriter_speed', '100', '打字机效果速度(毫秒)'),
('sakura_enabled', '0', '是否启用樱花飘落效果(1/0)'),
('background_image', '', '背景图片地址'),
('max_file_size', '5242880', '最大文件大小(字节)，默认5MB'),
('allowed_extensions', 'jpg,jpeg,png,gif,bmp,webp', '允许的文件扩展名'),
('upload_path', 'uploads/', '上传文件存储路径');

-- 初始化默认公告
INSERT IGNORE INTO `notices` (`position`, `content`, `is_active`) VALUES
('home', '', 0),
('login', '<div class="alert alert-warning">请使用您的账号登录以享受更多功能。</div>', 1),
('register', '<div class="alert alert-success">注册成功后，您可以管理您的图片并享受更多服务。</div>', 1); 
-- 为现有图床系统添加樱花效果和背景图配置项
INSERT IGNORE INTO `configs` (`name`, `value`, `description`) VALUES 
('sakura_enabled', '0', '是否启用樱花飘落效果(1/0)'),
('background_image', '', '背景图片地址');